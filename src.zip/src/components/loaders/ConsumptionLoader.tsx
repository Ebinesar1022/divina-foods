import { useState, useEffect } from "react";
import { Box, Typography, keyframes } from "@mui/material";
import RestaurantIcon from "@mui/icons-material/Restaurant";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import Inventory2Icon from "@mui/icons-material/Inventory2";
import TaskAltIcon from "@mui/icons-material/TaskAlt";

const shimmerBar = keyframes`
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;

const pulseGlow = keyframes`
  0%, 100% { opacity: 0.6; transform: scale(1); }
  50% { opacity: 1; transform: scale(1.05); }
`;

const consumptionSteps = [
  {
    title: "Quality Inspection & Batch Boxing Complete",
    desc: "Confirming produced unit counts and verifying final batch scrap calculations...",
  },
  {
    title: "Chef Transferring Boxed Pizzas to Finished Warehouse",
    desc: "Moving freshly packaged artisan pizzas from the oven line to cold storage depot...",
  },
  {
    title: "Registering Batch Numbers, MFD & Expiry Dates",
    desc: "Assigning traceability lot identifiers and shelf-life compliance records...",
  },
  {
    title: "Deducting Consumed Raw Materials from Kitchen Stock",
    desc: "Balancing allocated ingredients and logging actual quantities consumed...",
  },
  {
    title: "Synchronizing Finished Goods with Zoho Creator",
    desc: "Updating finished product inventory and closing out the production run...",
  },
];

export default function ConsumptionLoader() {
  const [currentStep, setCurrentStep] = useState(0);
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const stepTimer = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % consumptionSteps.length);
    }, 3600);

    const elapsedTimer = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);

    return () => {
      clearInterval(stepTimer);
      clearInterval(elapsedTimer);
    };
  }, []);

  const activeStep = consumptionSteps[currentStep];

  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        py: { xs: 2.5, sm: 3.5 },
        px: { xs: 1.5, sm: 3 },
        bgcolor: "#F0FDF4",
        borderRadius: "20px",
        position: "relative",
        userSelect: "none",
        overflow: "hidden",
      }}
    >
      {/* Ambient background glows */}
      <Box
        sx={{
          position: "absolute",
          top: -50,
          left: -50,
          width: 220,
          height: 220,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(234,88,12,0.12) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <Box
        sx={{
          position: "absolute",
          bottom: -50,
          right: -50,
          width: 240,
          height: 240,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(16,185,129,0.15) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Top Header Badge & Transfer Indicator */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: { xs: 1, sm: 1.5 },
          px: { xs: 1.5, sm: 2.25 },
          py: 0.75,
          borderRadius: "999px",
          bgcolor: "#FFFFFF",
          border: "1px solid rgba(187,247,208,0.8)",
          boxShadow: "0 2px 10px rgba(5,150,105,0.08)",
          mb: 1.5,
          maxWidth: "100%",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75, color: "#EA580C" }}>
          <RestaurantIcon sx={{ fontSize: { xs: 16, sm: 18 }, color: "#EA580C" }} />
          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, fontWeight: 700, letterSpacing: "0.02em" }}>
            Baking Kitchen
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 0.5,
            color: "#10B981",
            animation: `${pulseGlow} 2s ease-in-out infinite`,
          }}
        >
          <ArrowForwardIcon sx={{ fontSize: { xs: 14, sm: 16 } }} />
        </Box>

        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75, color: "#065F46" }}>
          <Inventory2Icon sx={{ fontSize: { xs: 16, sm: 18 }, color: "#059669" }} />
          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, fontWeight: 700, letterSpacing: "0.02em" }}>
            Finished Goods Warehouse
          </Typography>
        </Box>
      </Box>

      {/* Main Animated Scene SVG Container */}
      <Box
        sx={{
          width: "100%",
          maxWidth: 620,
          aspectRatio: "620 / 230",
          borderRadius: "16px",
          overflow: "hidden",
          border: "1px solid rgba(167,243,208,0.8)",
          boxShadow: "0 8px 24px rgba(5,150,105,0.08)",
          bgcolor: "#FFFFFF",
          position: "relative",
          mb: 2.5,
        }}
      >
        <svg
          viewBox="0 0 620 230"
          width="100%"
          height="100%"
          preserveAspectRatio="xMidYMid meet"
          style={{ display: "block" }}
        >
          <defs>
            {/* Gradients */}
            <linearGradient id="chefSkyGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FEF3C7" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#F0FDF4" />
            </linearGradient>

            <linearGradient id="brickOvenKitchen" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#B91C1C" />
              <stop offset="60%" stopColor="#991B1B" />
              <stop offset="100%" stopColor="#7F1D1D" />
            </linearGradient>

            <radialGradient id="ovenFireGlow2" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FEF08A" stopOpacity="1" />
              <stop offset="40%" stopColor="#F59E0B" stopOpacity="0.9" />
              <stop offset="80%" stopColor="#DC2626" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#991B1B" stopOpacity="0" />
            </radialGradient>

            <linearGradient id="boxCraft" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#D97706" />
              <stop offset="50%" stopColor="#B45309" />
              <stop offset="100%" stopColor="#92400E" />
            </linearGradient>

            <linearGradient id="boxLid" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="100%" stopColor="#D97706" />
            </linearGradient>

            <linearGradient id="warehouseRackSteel" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#0F172A" />
              <stop offset="50%" stopColor="#334155" />
              <stop offset="100%" stopColor="#1E293B" />
            </linearGradient>

            <linearGradient id="shelfSafetyBeam" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>

            <linearGradient id="laserBeamGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#34D399" stopOpacity="0.1" />
            </linearGradient>

            <linearGradient id="chefFloorGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#E2E8F0" />
              <stop offset="50%" stopColor="#F1F5F9" />
              <stop offset="100%" stopColor="#CBD5E1" />
            </linearGradient>

            <style>{`
              @keyframes chefWalkCycle {
                0% { transform: translateX(0px); }
                10% { transform: translateX(0px); }
                55% { transform: translateX(300px); }
                78% { transform: translateX(300px); }
                92% { transform: translateX(0px); opacity: 0.15; }
                95% { transform: translateX(0px); opacity: 1; }
                100% { transform: translateX(0px); }
              }

              @keyframes chefLegSwing1 {
                0%, 100% { transform: rotate(0deg); }
                25% { transform: rotate(26deg); }
                75% { transform: rotate(-26deg); }
              }

              @keyframes chefLegSwing2 {
                0%, 100% { transform: rotate(0deg); }
                25% { transform: rotate(-26deg); }
                75% { transform: rotate(26deg); }
              }

              @keyframes chefHatBob {
                0%, 100% { transform: translateY(0px) rotate(0deg); }
                50% { transform: translateY(-3px) rotate(2deg); }
              }

              @keyframes steamPuff1 {
                0% { transform: translateY(0) scale(0.6); opacity: 0; }
                30% { opacity: 0.85; }
                100% { transform: translateY(-24px) scale(1.4) translateX(-8px); opacity: 0; }
              }

              @keyframes steamPuff2 {
                0% { transform: translateY(0) scale(0.5); opacity: 0; }
                40% { opacity: 0.8; }
                100% { transform: translateY(-28px) scale(1.6) translateX(-12px); opacity: 0; }
              }

              @keyframes laserScan {
                0%, 100% { transform: translateY(0px); opacity: 0.3; }
                50% { transform: translateY(45px); opacity: 0.9; }
              }

              @keyframes pizzaBoxPop {
                0%, 55% { opacity: 0; transform: scale(0.6) translateY(6px); }
                65% { opacity: 1; transform: scale(1.12) translateY(-6px); }
                76% { opacity: 1; transform: scale(1) translateY(-4px); }
                88%, 100% { opacity: 0; transform: scale(0.9) translateY(-10px); }
              }

              @keyframes firePulse {
                0%, 100% { transform: scale(1); opacity: 0.85; }
                50% { transform: scale(1.15) translateY(-2px); opacity: 1; }
              }
            `}</style>
          </defs>

          {/* Background Wall & Floor */}
          <rect x="0" y="0" width="620" height="175" fill="url(#chefSkyGrad)" />
          {/* Wall separator */}
          <line x1="0" y1="175" x2="620" y2="175" stroke="#CBD5E1" strokeWidth="2" />
          {/* Floor */}
          <rect x="0" y="175" width="620" height="55" fill="url(#chefFloorGrad)" />

          {/* Floor Path Chevrons (Direction toward Warehouse) */}
          <rect x="140" y="194" width="340" height="14" rx="7" fill="#E2E8F0" />
          <line
            x1="150"
            y1="201"
            x2="470"
            y2="201"
            stroke="#059669"
            strokeWidth="3.5"
            strokeDasharray="8 6"
            strokeLinecap="round"
            style={{ animation: "chevronFlow 1.2s linear infinite" }}
          />

          {/* ══════════════ LEFT: PRODUCTION KITCHEN ══════════════ */}
          <g id="kitchenZone">
            {/* Zone Tag */}
            <rect x="12" y="12" width="134" height="22" rx="6" fill="#1E293B" opacity="0.9" />
            <text x="79" y="27" textAnchor="middle" fill="#FDBA74" fontSize="10.5" fontWeight="700" letterSpacing="0.04em">
              🍕 BAKING KITCHEN
            </text>

            {/* Brick Pizza Oven */}
            <path
              d="M 14 175 L 14 100 Q 64 52 118 100 L 118 175 Z"
              fill="url(#brickOvenKitchen)"
              stroke="#7F1D1D"
              strokeWidth="2"
            />
            {/* Oven decorative mortar lines */}
            <line x1="20" y1="120" x2="112" y2="120" stroke="#7F1D1D" strokeWidth="1.5" opacity="0.6" />
            <line x1="20" y1="140" x2="112" y2="140" stroke="#7F1D1D" strokeWidth="1.5" opacity="0.6" />
            <line x1="20" y1="160" x2="112" y2="160" stroke="#7F1D1D" strokeWidth="1.5" opacity="0.6" />

            {/* Oven Chamber Opening */}
            <path
              d="M 36 175 L 36 130 Q 66 110 96 130 L 96 175 Z"
              fill="#1F2937"
            />

            {/* Fiery Embers Glowing */}
            <ellipse
              cx="66"
              cy="162"
              rx="22"
              ry="11"
              fill="url(#ovenFireGlow2)"
              style={{ animation: "firePulse 1.8s ease-in-out infinite" }}
            />
            <circle cx="58" cy="164" r="3" fill="#FEF08A" />
            <circle cx="74" cy="163" r="2.5" fill="#FEF08A" />

            {/* Chimney */}
            <rect x="58" y="38" width="18" height="28" fill="#7F1D1D" />
            <rect x="55" y="35" width="24" height="6" rx="1.5" fill="#991B1B" />

            {/* Rising Oven Steam */}
            <ellipse cx="67" cy="28" rx="6" ry="12" fill="#FFFFFF" opacity="0.7" style={{ animation: "steamRise 2.2s ease-out infinite" }} />
            <ellipse cx="70" cy="24" rx="4" ry="10" fill="#FFFFFF" opacity="0.6" style={{ animation: "steamRise 2.4s ease-out infinite 0.7s" }} />

            {/* Wooden Pizza Peel Propped Up */}
            <line x1="122" y1="168" x2="138" y2="108" stroke="#92400E" strokeWidth="4" strokeLinecap="round" />
            <ellipse cx="140" cy="104" rx="10" ry="13" fill="#D97706" stroke="#92400E" strokeWidth="1.2" transform="rotate(15 140 104)" />

            {/* Kitchen Counter with Pizza Cutting Board */}
            <rect x="124" y="142" width="46" height="33" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="1.2" />
            <rect x="122" y="139" width="50" height="4" rx="1" fill="#F8FAFC" stroke="#64748B" strokeWidth="1" />
            {/* Rolling pizza cutter */}
            <circle cx="148" cy="134" r="5" fill="#CBD5E1" stroke="#475569" strokeWidth="1" />
            <line x1="148" y1="134" x2="156" y2="128" stroke="#DC2626" strokeWidth="2.5" strokeLinecap="round" />
          </g>

          {/* ══════════════ RIGHT: FINISHED GOODS WAREHOUSE ══════════════ */}
          <g id="warehouseFinishedZone">
            {/* Zone Tag */}
            <rect x="466" y="12" width="144" height="22" rx="6" fill="#1E293B" opacity="0.9" />
            <text x="538" y="27" textAnchor="middle" fill="#86EFAC" fontSize="10.5" fontWeight="700" letterSpacing="0.04em">
              📦 FINISHED GOODS
            </text>

            {/* Warehouse Heavy-Duty Rack */}
            {/* Left Upright */}
            <rect x="496" y="42" width="6" height="133" fill="url(#warehouseRackSteel)" />
            {/* Right Upright */}
            <rect x="600" y="42" width="6" height="133" fill="url(#warehouseRackSteel)" />
            {/* Cross bracing */}
            <line x1="502" y1="48" x2="600" y2="92" stroke="#64748B" strokeWidth="2" />
            <line x1="600" y1="48" x2="502" y2="92" stroke="#64748B" strokeWidth="2" />
            <line x1="502" y1="96" x2="600" y2="140" stroke="#64748B" strokeWidth="2" />
            <line x1="600" y1="96" x2="502" y2="140" stroke="#64748B" strokeWidth="2" />

            {/* Top Green Storage Shelf */}
            <rect x="492" y="88" width="118" height="7" rx="2" fill="url(#shelfSafetyBeam)" />
            {/* Stack of Divina Pizza Boxes on top shelf */}
            <g transform="translate(510, 56)">
              {/* Box 1 */}
              <rect x="0" y="18" width="46" height="12" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
              <rect x="14" y="20" width="18" height="4" rx="1" fill="#DC2626" />
              <text x="23" y="23.5" textAnchor="middle" fill="#FFFFFF" fontSize="5" fontWeight="bold">DIVINA</text>
              {/* Box 2 */}
              <rect x="2" y="8" width="44" height="12" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
              <rect x="15" y="10" width="18" height="4" rx="1" fill="#DC2626" />
              {/* Box 3 */}
              <rect x="4" y="-1" width="42" height="11" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
              <rect x="16" y="1" width="18" height="4" rx="1" fill="#DC2626" />
            </g>

            {/* Second stack on top shelf */}
            <g transform="translate(560, 68)">
              <rect x="0" y="8" width="34" height="12" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
              <rect x="2" y="-1" width="32" height="11" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
            </g>

            {/* Bottom Green Storage Shelf */}
            <rect x="492" y="136" width="118" height="7" rx="2" fill="url(#shelfSafetyBeam)" />
            {/* Receiving Pallet & Stored Box Stacks on lower shelf */}
            <g transform="translate(506, 102)">
              {/* Stored pizza cartons awaiting dispatch */}
              <rect x="0" y="20" width="50" height="13" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
              <rect x="16" y="22" width="18" height="4" rx="1" fill="#DC2626" />
              <text x="25" y="25.5" textAnchor="middle" fill="#FFFFFF" fontSize="5" fontWeight="bold">DIVINA</text>
              {/* Stack atop */}
              <rect x="2" y="8" width="46" height="13" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
              <rect x="16" y="10" width="18" height="4" rx="1" fill="#DC2626" />
            </g>

            {/* Overhead Barcode Scanning Laser Beam */}
            <g transform="translate(530, 42)">
              {/* Scanner head */}
              <rect x="0" y="0" width="28" height="6" rx="2" fill="#0F172A" />
              <circle cx="14" cy="6" r="2" fill="#10B981" />
              {/* Laser line moving vertically */}
              <line
                x1="-10"
                y1="16"
                x2="38"
                y2="16"
                stroke="#10B981"
                strokeWidth="1.5"
                opacity="0.8"
                style={{ animation: "laserScan 2.4s ease-in-out infinite" }}
              />
            </g>

            {/* Bottom wooden pallet */}
            <rect x="502" y="166" width="102" height="9" fill="#92400E" />
            <rect x="510" y="169" width="12" height="6" fill="#1E293B" />
            <rect x="548" y="169" width="12" height="6" fill="#1E293B" />
            <rect x="586" y="169" width="12" height="6" fill="#1E293B" />

            {/* "+ Lot Stored & Verified" Pop-up Achievement Burst */}
            <g style={{ animation: "pizzaBoxPop 6s ease-in-out infinite" }}>
              <rect x="442" y="78" width="124" height="26" rx="8" fill="#059669" />
              <text x="504" y="95" textAnchor="middle" fill="#FFFFFF" fontSize="10" fontWeight="800">
                ✓ BOXES STORED!
              </text>
              <polygon points="504,104 498,98 510,98" fill="#059669" />
            </g>
          </g>

          {/* ══════════════ MOVING HERO: EXECUTIVE CHEF WITH BOXED PIZZAS ══════════════ */}
          <g style={{ animation: "chefWalkCycle 6s cubic-bezier(0.45, 0.05, 0.55, 0.95) infinite" }}>
            <g transform="translate(130, 96)">
              {/* Chef Back Leg */}
              <g transform="translate(12, 60)" style={{ animation: "chefLegSwing1 0.6s ease-in-out infinite", transformOrigin: "4px 0px" }}>
                <rect x="0" y="0" width="8" height="26" rx="4" fill="#1E293B" />
                {/* Polished Black Shoe */}
                <path d="M 0 24 L 14 24 L 14 29 L -2 29 Z" fill="#0F172A" />
              </g>

              {/* Chef Front Leg */}
              <g transform="translate(20, 60)" style={{ animation: "chefLegSwing2 0.6s ease-in-out infinite", transformOrigin: "4px 0px" }}>
                <rect x="0" y="0" width="8" height="26" rx="4" fill="#334155" />
                {/* Polished Black Shoe */}
                <path d="M 0 24 L 14 24 L 14 29 L -2 29 Z" fill="#0F172A" />
              </g>

              {/* Torso & Uniform */}
              <g transform="translate(8, 24)" style={{ animation: "chefHatBob 0.6s ease-in-out infinite" }}>
                {/* Double-breasted Chef Jacket */}
                <rect x="0" y="6" width="22" height="32" rx="4" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="1" />
                {/* Red Neckerchief */}
                <polygon points="4,6 18,6 11,14" fill="#DC2626" />
                {/* Double breast buttons */}
                <circle cx="7" cy="18" r="1.2" fill="#0F172A" />
                <circle cx="15" cy="18" r="1.2" fill="#0F172A" />
                <circle cx="7" cy="24" r="1.2" fill="#0F172A" />
                <circle cx="15" cy="24" r="1.2" fill="#0F172A" />
                <circle cx="7" cy="30" r="1.2" fill="#0F172A" />
                <circle cx="15" cy="30" r="1.2" fill="#0F172A" />

                {/* Chef Apron Strings */}
                <rect x="0" y="32" width="22" height="8" rx="2" fill="#F8FAFC" />

                {/* Friendly Chef Head */}
                <circle cx="11" cy="-4" r="9" fill="#FDE68A" />
                {/* Chef Eyes */}
                <circle cx="15" cy="-5" r="1.2" fill="#0F172A" />
                {/* Cheerful Italian Mustache */}
                <path d="M 11 -1 Q 14 -3 17 -1 Q 19 2 17 3 Q 14 0 11 2 Z" fill="#451A03" />
                <circle cx="15.5" cy="-2.5" r="1" fill="#F87171" opacity="0.6" />

                {/* Iconic Tall White Chef Toque (Hat) */}
                <g transform="translate(2, -26)">
                  {/* Hat headband */}
                  <rect x="1" y="16" width="16" height="6" rx="1" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="0.8" />
                  {/* Pleated puffs */}
                  <path
                    d="M 1 16 C -3 10, -1 0, 9 0 C 19 0, 21 10, 17 16 Z"
                    fill="#FFFFFF"
                    stroke="#E2E8F0"
                    strokeWidth="1"
                  />
                  <ellipse cx="9" cy="2" rx="7" ry="3" fill="#F8FAFC" />
                </g>

                {/* Chef Arms holding the Boxed Pizza Stack */}
                <path d="M 16 16 Q 26 24 30 18" stroke="#FFFFFF" strokeWidth="5.5" strokeLinecap="round" fill="none" />
                <circle cx="30" cy="18" r="3" fill="#FDE68A" />
                <path d="M 12 18 Q 22 28 28 20" stroke="#E2E8F0" strokeWidth="5" strokeLinecap="round" fill="none" />
              </g>

              {/* ── Freshly Baked Boxed Pizzas Carried in Hands ── */}
              <g transform="translate(36, 32)" style={{ animation: "chefHatBob 0.6s ease-in-out infinite" }}>
                {/* Rising Hot Pizza Steam Trails from Boxes */}
                <ellipse cx="18" cy="-6" rx="4" ry="10" fill="#FFFFFF" opacity="0.8" style={{ animation: "steamPuff1 1.8s ease-out infinite" }} />
                <ellipse cx="26" cy="-10" rx="3" ry="8" fill="#FFFFFF" opacity="0.75" style={{ animation: "steamPuff2 2.1s ease-out infinite 0.6s" }} />

                {/* Box 1 (Bottom Box) */}
                <g transform="translate(0, 16)">
                  <rect x="0" y="0" width="38" height="10" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
                  <rect x="10" y="2" width="18" height="3" rx="1" fill="#DC2626" />
                  <text x="19" y="4.5" textAnchor="middle" fill="#FFFFFF" fontSize="4.5" fontWeight="bold">DIVINA</text>
                  {/* Steam vents on side */}
                  <circle cx="4" cy="5" r="0.8" fill="#78350F" />
                  <circle cx="34" cy="5" r="0.8" fill="#78350F" />
                </g>

                {/* Box 2 (Middle Box) */}
                <g transform="translate(1, 6)">
                  <rect x="0" y="0" width="36" height="10" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
                  <rect x="9" y="2" width="18" height="3" rx="1" fill="#DC2626" />
                  <text x="18" y="4.5" textAnchor="middle" fill="#FFFFFF" fontSize="4.5" fontWeight="bold">DIVINA</text>
                </g>

                {/* Box 3 (Top Box) */}
                <g transform="translate(2, -4)">
                  <rect x="0" y="0" width="34" height="10" rx="2" fill="url(#boxCraft)" stroke="#78350F" strokeWidth="1" />
                  {/* Pizza Lid Branding */}
                  <rect x="8" y="2" width="18" height="3" rx="1" fill="#DC2626" />
                  <text x="17" y="4.5" textAnchor="middle" fill="#FFFFFF" fontSize="4.5" fontWeight="bold">DIVINA</text>
                  {/* Golden Quality Ribbon / Sticker */}
                  <circle cx="30" cy="5" r="2.5" fill="#F59E0B" stroke="#D97706" strokeWidth="0.5" />
                </g>
              </g>
            </g>
          </g>
        </svg>
      </Box>

      {/* Progress & Current Phase Tracker */}
      <Box
        sx={{
          width: "100%",
          maxWidth: 540,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
        }}
      >
        {/* Dynamic Step Title */}
        <Typography
          sx={{
            fontWeight: 800,
            fontSize: { xs: 14.5, sm: 16.5 },
            color: "#064E3B",
            letterSpacing: "-0.01em",
            mb: 0.5,
            transition: "all 0.3s ease",
          }}
        >
          {activeStep.title}
        </Typography>

        {/* Dynamic Step Description */}
        <Typography
          sx={{
            fontSize: { xs: 12, sm: 13 },
            color: "#047857",
            maxWidth: 480,
            lineHeight: 1.45,
            mb: 2,
            minHeight: { xs: 36, sm: 28 },
          }}
        >
          {activeStep.desc}
        </Typography>

        {/* Shimmering Progress Bar (Emerald/Teal/Amber) */}
        <Box
          sx={{
            width: "100%",
            height: 7,
            borderRadius: "999px",
            bgcolor: "#D1FAE5",
            overflow: "hidden",
            position: "relative",
            boxShadow: "inset 0 1px 2px rgba(0,0,0,0.06)",
            mb: 2,
          }}
        >
          <Box
            sx={{
              width: "100%",
              height: "100%",
              borderRadius: "999px",
              background:
                "linear-gradient(90deg, #059669 0%, #10B981 25%, #F59E0B 50%, #065F46 75%, #059669 100%)",
              backgroundSize: "200% 100%",
              animation: `${shimmerBar} 2.4s linear infinite`,
            }}
          />
        </Box>

        {/* Bottom Details Footer */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            width: "100%",
            px: 1,
            color: "#065F46",
            fontSize: 12,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
            <TaskAltIcon sx={{ fontSize: 15, color: "#059669" }} />
            <Typography sx={{ fontSize: { xs: 11, sm: 12 }, fontWeight: 600, color: "#047857" }}>
              Writing finished goods batches
            </Typography>
          </Box>

          <Box
            sx={{
              display: "inline-flex",
              alignItems: "center",
              gap: 0.75,
              px: 1.25,
              py: 0.25,
              borderRadius: "999px",
              bgcolor: "#ECFDF5",
              border: "1px solid #A7F3D0",
            }}
          >
            <Box
              sx={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                bgcolor: "#059669",
                animation: `${pulseGlow} 1.5s infinite`,
              }}
            />
            <Typography sx={{ fontSize: 11, fontWeight: 700, color: "#065F46" }}>
              Active • {elapsed}s
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
