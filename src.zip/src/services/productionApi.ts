// ─────────────────────────────────────────────
// productionApi.ts
// All calls use .then()/.catch() chains instead of async/await,
// matching the pattern used across Divina Foods' other Creator
// widgets (see maint-dashboard reference) — plain Promise chaining
// is the safest path for widget code running inside the Creator
// mobile app's embedded iOS Safari webview.
// ─────────────────────────────────────────────

import type {
  BatchAllocationLine,
  BomItemRow,
  ConsumptionEntryDraft,
  ConsumptionEntryRow,
  CreateMrpResult,
  CreatePoDraft,
  EmployeeOption,
  FinishedGoodTargetRow,
  MrpDetailData,
  MrpDraft,
  MrpRow,
  NonStockItemRow,
  PaymentTermOption,
  PoLineRow,
  ProductionInProgressRow,
  ProductionTargetRow,
  ProductionTargetStatus,
  PurchaseOrderDetail,
  RawMaterialNeedRow,
  ReceivePoDraft,
  StartProductionDetails,
  SupplierOption,
  TaxOption,
} from "../types";

declare global {
  interface Window {
    ZOHO: any;
  }
}

// ⚠️ Confirm every *_REPORT value against Creator → Reports (case sensitive).
// These are the 5 pipeline stages; Procurement covers 2 forms (PO + PR)
// that get merged into a single "Procurement" tab/stage in the UI.
export const CONFIG = {
  APP_NAME: "divina-foods",
  PRODUCTION_TARGET_REPORT: "Production_Target_Report",
  MRP_REPORT: "Material_Requirement_Planning_Report",
  PURCHASE_ORDER_REPORT: "Purchase_Order_Report",
  PURCHASE_RECEIVE_REPORT: "Purchase_Receive_Report",
  PRODUCTION_INPROGRESS_REPORT: "Production_Inprogress",
  CONSUMPTION_ENTRY_REPORT: "Consumption_Entry_Report",

  // Confirmed against the app's .ds export (Divina_Foods_3.ds).
  FINISHED_GOODS_REPORT: "Finished_Goods_Report",
  FINISHED_GOODS_FORM: "Finished_Goods",
  BOM_MASTER_REPORT: "BOM_Master_Report",
  BOM_ITEMS_REPORT: "BOM_Items_Report",
  MAIN_WAREHOUSE_STOCK_REPORT: "Main_Warehouse_Stock_Details_Report",
  // ⚠️ Following this file's report-name-minus-"_Report" convention (holds
  // for every other form/report pair above) — confirm against Creator if a
  // new-row insert ever comes back "Failed to create a record".
  MAIN_WAREHOUSE_STOCK_FORM: "Main_Warehouse_Stock_Details",
  SEQUENCE_MASTER_REPORT: "Sequence_Master_Report",
  // Confirmed against live DevTools traffic: this is a report directly on
  // Warehouse_Master (not a separate "Warehouse" wrapper form), listing
  // every physical warehouse (Main, Production, Scrap, ...) with
  // Warehouse_Name as plain text — not a lookup.
  WAREHOUSE_REPORT: "Warehouse_Master_Report",
  MRP_FORM: "Material_Requirement_Planning",
  RAW_MATERIALS_FORM: "Raw_Materials",
  RAW_MATERIALS_REPORT: "Raw_Materials_Report",

  EMPLOYEE_REPORT: "Employee_Report",

  // Confirmed against the app's .ds export (Divina_Foods_6.ds) — the
  // "Required Materials" custom action on the MRP list opens
  // Non_Stock_Items_Report?MRP_ID=<MRP_ID>, which reads from this
  // separate Non_Stock_Items form, NOT Raw_Materials.
  NON_STOCK_ITEMS_FORM: "Non_Stock_Items",
  NON_STOCK_ITEMS_REPORT: "Non_Stock_Items_Report",
  UOM_MASTER_REPORT: "UOM_Master_Report",

  // Confirmed against the app's .ds export (Divina_Foods_7.ds) — the full
  // Procurement flow: Purchase_Order has a PO_Line_Items grid (per-product
  // order lines), Purchase_Receive has a Receive_Items grid (per-product
  // received quantities for one receipt against one PO).
  PURCHASE_ORDER_FORM: "Purchase_Order",
  PO_LINE_ITEMS_FORM: "PO_Line_Items",
  PO_LINE_ITEMS_REPORT: "PO_Line_Items_Report",
  PURCHASE_RECEIVE_FORM: "Purchase_Receive",
  RECEIVE_ITEMS_FORM: "Receive_Items",
  RECEIVE_ITEMS_REPORT: "Receive_Items_Report",
  SUPPLIER_REPORT: "Supplier_Report",
  PAYMENT_TERM_REPORT: "Payment_Term_Report",
  TAX_MASTER_REPORT: "Tax_Master_Report",

  // Confirmed against the app's .ds export (Divina_Foods_5.ds) —
  // Consumption_Entry's two grids (Finished_Good, Raw_Material_Consumptions)
  // are subform-backing forms, same pattern as MRP's Finished_Goods/Raw_Materials.
  CONSUMPTION_ENTRY_FORM: "Consumption_Entry",
  FINISHED_GOODS_CONSUMPTIONS_FORM: "Finished_Goods_Cunsumptions",
  FINISHED_GOODS_CONSUMPTIONS_REPORT: "Finished_Goods_Cunsumptions_Report",
  CONSUMPTION_ITEMS_FORM: "Consumption_Items",
  CONSUMPTION_ITEMS_REPORT: "Consumption_Items_Report",

  // Warehouse stock ledgers touched by completing production — confirmed
  // against the app's .ds export. All three are plain Creator forms (no
  // external Zoho Inventory connection involved), unlike the separate
  // "Update Inventory Adjustment" workflow.
  SCRAP_WAREHOUSE_STOCK_REPORT: "Scrap_Warehouse_Stock_Details_Report",
  // ⚠️ Same report-name-minus-"_Report" convention as MAIN_WAREHOUSE_STOCK_FORM —
  // confirm against Creator if a new-row insert ever comes back "Failed to
  // create a record".
  SCRAP_WAREHOUSE_STOCK_FORM: "Scrap_Warehouse_Stock_Details",
  PRODUCTION_STOCK_REPORT: "Production_Stock_Details_Report",
  // Per-batch stock ledger on Product_Master — same report-name-minus-
  // "_Report" form-name convention as the other pairs above.
  BATCH_DETAILS_REPORT: "All_Batch_Details",
  BATCH_DETAILS_FORM: "Batch_Details",

  // Confirmed against the app's .ds export — FEFO_Batch_Allocation (header,
  // Production_Targets lookup) + Batch_Allocation (its grid, linked back via
  // FEFO_Batch_ID) is the native persistent record for a Start Production
  // run's FEFO pick. AllocateAndCommitBatch now writes one of these so the
  // widget can read it back after a reload instead of only holding it in
  // React state.
  FEFO_BATCH_ALLOCATION_REPORT: "FEFO_Batch_Allocation_Report",
  BATCH_ALLOCATION_REPORT: "All_Batch_Allocations",

  // File Upload field on Production_Targets that receives the generated
  // Batch Allocation PDF on phones (the Creator mobile app's webview can't
  // save a Blob download, so the PDF is opened from a real Creator URL).
  BATCH_ALLOCATION_PDF_FIELD: "Batch_Allocation_PDF",
  // Fallbacks for the file URL — the origin normally comes from the widget's
  // own ?serviceOrigin=… (see creatorServiceOrigin). Owner/app read from the
  // live app URL: https://creatorapp.zoho.com.au/<ACCOUNT_OWNER>/<APP_NAME>/
  CREATOR_ORIGIN: "https://creatorapp.zoho.com.au",
  ACCOUNT_OWNER: "info_divinafoodco",
};

function display(value: any): string {
  if (value == null) return "";
  if (typeof value === "string" || typeof value === "number")
    return String(value);
  if (typeof value === "object") {
    return value.zc_display_value || value.display_value || value.Name || "";
  }
  return "";
}

// Pulls the raw record ID out of a lookup field's response shape
// ({ ID, zc_display_value, ... }), falling back to the raw value itself
// when the field already comes back as a bare ID string.
function lookupId(value: any): string {
  if (value == null) return "";
  if (typeof value === "object")
    return value.ID != null ? String(value.ID) : "";
  return String(value);
}

// Rounds a computed quantity to 4 decimal places before it's ever written
// to Zoho. BOM math (quantityRequired * targetQuantity, then summed across
// finished goods) routinely lands on IEEE754 noise like 0.30000000000000004
// — that has 17 significant digits once JSON-serialized, which Creator's
// decimal fields reject outright with "<Field> has exceeded its maximum
// digits" (code 3001). Rounding at the point every derived quantity is
// produced keeps that noise from ever reaching a payload.
function roundQty(value: number): number {
  if (!isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 10000) / 10000;
}

// Same IEEE754-noise problem as roundQty, but for currency fields
// (Unit_Price, Line_Total, Tax_Amount, Sub_Total, Grand_Total). Those are
// configured in Creator with 2 decimal places, not 4 — rounding tax math
// (Line_Total * Tax_Percentage / 100) to 4 decimals routinely leaves a
// 3rd/4th decimal digit (e.g. 9.9998), which Creator rejects the same way
// with "<Field> has exceeded its maximum digits" (code 3001).
function roundMoney(value: number): number {
  if (!isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

// Employee.Employee_Name is a "name"-type field — comes back as
// { prefix, first_name, last_name, suffix }, matching the displayformat
// used for Assigned_To lookups elsewhere in the app (Production_Targets,
// Production_Order): "prefix first_name last_name suffix".
function formatEmployeeName(nameField: any): string {
  if (!nameField || typeof nameField !== "object") return "";
  return [
    nameField.prefix,
    nameField.first_name,
    nameField.last_name,
    nameField.suffix,
  ]
    .filter(Boolean)
    .join(" ")
    .trim();
}

// Generic fetch — every read on this page goes through this one function.
function getRecords(
  reportName: string,
  criteria?: string,
  maxRecords = 200,
): Promise<any[]> {
  return window.ZOHO.CREATOR.DATA.getRecords({
    app_name: CONFIG.APP_NAME,
    report_name: reportName,
    criteria: criteria || "",
    field_config: "all",
    max_records: maxRecords,
  })
    .then(function (resp: any) {
      if (!resp || resp.code !== 3000 || !resp.data) return [];
      return resp.data;
    })
    .catch(function (err: any) {
      // Creator throws a rejected promise (not code 3000) when a report has 0 rows.
      if (
        err &&
        (err.code === 9280 || /no records? found/i.test(err.message || ""))
      ) {
        return [];
      }
      console.error("getRecords failed for " + reportName, err);
      return [];
    });
}

// Zoho Creator enforces a low cap on simultaneous in-flight API calls per
// session — firing a get/update for every line of a multi-line record
// (several finished goods, several raw materials, each needing 2-3 lookups
// plus updates) via Promise.all blows past that cap and every call past it
// comes back `{ code: 2955, description: "You have reached the maximum
// number of API calls that can be simultaneously initiated at a time." }`.
// Chains each item's work with .then() instead, one request at a time.
function runSequentially<T, R>(
  items: T[],
  task: (item: T) => Promise<R>,
): Promise<R[]> {
  const results: R[] = [];
  return items
    .reduce(function (chain: Promise<void>, item) {
      return chain.then(function () {
        return task(item).then(function (result) {
          results.push(result);
        });
      });
    }, Promise.resolve())
    .then(function () {
      return results;
    });
}

// Generic create — every write this widget does (MRP header, Finished_Goods
// links, Raw_Materials rows) goes through this one function.
function addRecord(formName: string, data: Record<string, any>): Promise<any> {
  return window.ZOHO.CREATOR.DATA.addRecords({
    app_name: CONFIG.APP_NAME,
    form_name: formName,
    payload: {
      data: data,
    },
  }).then(function (resp: any) {
    if (!resp || resp.code !== 3000 || !resp.data) {
      return Promise.reject(
        new Error("Failed to create a record in " + formName + "."),
      );
    }
    return resp.data;
  });
}

// Generic update — used to bump Sequence_Master's counter and to link an
// existing Finished_Goods row to the MRP that was just created for it.
//
// NOTE: the JS SDK's update call is `updateRecordById`, not `updateRecords`
// (that method doesn't exist on the SDK) — and it takes `report_name`, not
// `form_name`, same as getRecords. Confirmed against Zoho's own docs:
// https://www.zoho.com/creator/help/js-api/v2/update-specific-record.html
// Getting this wrong made every update reject before any network request
// was even sent, silently dropping the Finished_Goods MRP_ID link-back and
// the sequence bump while the rest of the create had already succeeded.
function updateRecord(
  reportName: string,
  recordId: string,
  data: Record<string, any>,
): Promise<any> {
  return window.ZOHO.CREATOR.DATA.updateRecordById({
    app_name: CONFIG.APP_NAME,
    report_name: reportName,
    id: recordId,
    payload: {
      data: data,
    },
  }).then(function (resp: any) {
    if (!resp || resp.code !== 3000) {
      return Promise.reject(
        new Error(
          "Failed to update record " + recordId + " in " + reportName + ".",
        ),
      );
    }
    return resp.data;
  });
}

// Generic delete — same report_name convention as updateRecord (the SDK's
// deleteRecordById call, like updateRecordById, addresses by report, not
// form). Used to remove a Batch_Details row once FEFO consumption has
// emptied it out, mirroring the native workflow's own
// "delete from Batch_Details[...]" step.
function deleteRecord(reportName: string, recordId: string): Promise<any> {
  return window.ZOHO.CREATOR.DATA.deleteRecordById({
    app_name: CONFIG.APP_NAME,
    report_name: reportName,
    id: recordId,
  }).then(function (resp: any) {
    if (!resp || resp.code !== 3000) {
      return Promise.reject(
        new Error(
          "Failed to delete record " + recordId + " in " + reportName + ".",
        ),
      );
    }
    return resp;
  });
}

// ───────────── Batch allocation PDF (Creator mobile app) ─────────────
// Creator SDK rejections arrive in several shapes — a bare string, an Error,
// or the API's own { code, description | message } body — so flatten
// whichever one shows up into a single readable line for the UI.
export function describeError(err: any): string {
  if (err == null) return "";
  if (typeof err === "string") return err;
  const text = err.description || err.message || err.error_message || "";
  const code = err.code != null ? String(err.code) : "";
  if (text || code) return (code ? code + " – " : "") + text;
  try {
    return JSON.stringify(err).slice(0, 160);
  } catch {
    return String(err);
  }
}

// A file field's value comes back as a download path whose `filepath` query
// param is the stored file's internal name — same thing uploadFile returns.
function filePathFromFieldValue(value: any): string {
  const match =
    typeof value === "string" ? value.match(/[?&]filepath=([^&]+)/) : null;
  return match ? decodeURIComponent(match[1]).replace(/^\//, "") : "";
}

function parseMaybeJson(value: any): any {
  if (typeof value !== "string") return value;
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

// The upload response's exact shape isn't guaranteed by the SDK — the docs
// show { code, data: { filepath } }, but it can also be flat, a JSON string,
// or spell the key filePath/file_path — so search the whole thing for it.
function findFilePath(value: any, depth: number): string {
  if (value == null || depth > 4) return "";
  if (typeof value === "string") return filePathFromFieldValue(value);
  if (typeof value !== "object") return "";
  const keys = Object.keys(value);
  for (let i = 0; i < keys.length; i++) {
    const item = value[keys[i]];
    if (/^file_?path$/i.test(keys[i]) && typeof item === "string" && item) {
      return item.replace(/^\//, "");
    }
  }
  for (let i = 0; i < keys.length; i++) {
    const found = findFilePath(value[keys[i]], depth + 1);
    if (found) return found;
  }
  return "";
}

// The origin Creator serves this widget (and its files) from. The widget's
// own URL carries it as ?serviceOrigin=… — the app builder's
// creator.zoho.com.au is a different host, so the config value is only a
// fallback.
function creatorServiceOrigin(): string {
  const match = window.location.search.match(/[?&]serviceOrigin=([^&]+)/);
  if (match) {
    const origin = decodeURIComponent(match[1]).replace(/\/+$/, "");
    if (/^https:\/\/[\w-]+(\.[\w-]+)*\.zoho\.[a-z]+(\.[a-z]+)?$/i.test(origin)) {
      return origin;
    }
  }
  return CONFIG.CREATOR_ORIGIN;
}

// The SDK's uploadFile only reads `.name` off the file and hands it to
// FileReader, so a named Blob is enough where `new File()` isn't available.
function toUploadFile(blob: Blob, filename: string): File {
  try {
    return new File([blob], filename, { type: "application/pdf" });
  } catch {
    const named: any = blob;
    named.name = filename;
    return named as File;
  }
}

// Uploads the PDF into Production_Targets.Batch_Allocation_PDF. Resolves
// with the Creator URL that opens it in the signed-in session, or null when
// the file was saved but its stored path couldn't be worked out (so there's
// no URL to build). Rejects only if the upload itself failed.
//
// NOTE: the upload is an edit of the Production_Targets record, so its
// on-edit workflows run — the SDK's uploadFile has no way to skip them.
export function uploadBatchAllocationPdf(
  productionTargetRecordId: string,
  blob: Blob,
  filename: string,
): Promise<string | null> {
  // Starting from a resolved promise turns a synchronous throw (SDK missing
  // `FILE`, bad argument) into a rejection callers can handle like any other.
  return Promise.resolve()
    .then(function () {
      return window.ZOHO.CREATOR.FILE.uploadFile({
        app_name: CONFIG.APP_NAME,
        report_name: CONFIG.PRODUCTION_TARGET_REPORT,
        id: productionTargetRecordId,
        field_name: CONFIG.BATCH_ALLOCATION_PDF_FIELD,
        file: toUploadFile(blob, filename),
      });
    })
    .then(function (rawResp: any) {
      const resp = parseMaybeJson(rawResp);
      if (!resp || (resp.code != null && resp.code !== 3000)) {
        return Promise.reject(
          new Error(
            "Upload rejected" +
              (resp ? " (" + describeError(resp) + ")" : "") +
              ".",
          ),
        );
      }
      const fromResponse = findFilePath(resp, 0);
      if (fromResponse) return fromResponse;
      // Response carried no path — read it back off the record instead
      // (only works if the field is a column of the report).
      return getRecords(
        CONFIG.PRODUCTION_TARGET_REPORT,
        "ID == " + productionTargetRecordId,
        200,
      ).then(function (rows) {
        const fromRecord = rows.length
          ? filePathFromFieldValue(rows[0][CONFIG.BATCH_ALLOCATION_PDF_FIELD])
          : "";
        if (!fromRecord) {
          console.warn(
            "Batch allocation PDF was saved, but its file path wasn't found in the upload response:",
            rawResp,
          );
        }
        return fromRecord;
      });
    })
    .then(function (filePath: string) {
      if (!filePath) return null;
      return (
        creatorServiceOrigin() +
        "/file/" +
        CONFIG.ACCOUNT_OWNER +
        "/" +
        CONFIG.APP_NAME +
        "/" +
        CONFIG.PRODUCTION_TARGET_REPORT +
        "/" +
        productionTargetRecordId +
        "/" +
        CONFIG.BATCH_ALLOCATION_PDF_FIELD +
        "/download?filepath=/" +
        encodeURIComponent(filePath)
      );
    });
}

// The widget is a sandboxed iframe inside a Creator page, so it can't open
// windows or navigate the page itself — the Creator shell does it through
// navigateParentURL. Fire-and-forget: the SDK's promise may never settle
// once the shell takes over navigation.
export function openInParentWindow(url: string): void {
  const nav = window.ZOHO.CREATOR.UTIL.navigateParentURL({
    action: "open",
    url: url,
    window: "new",
  });
  if (nav && typeof nav.catch === "function") nav.catch(function () {});
}

function navigateTopOrSelf(url: string): void {
  try {
    if (window.top) {
      window.top.location.href = url;
      return;
    }
  } catch (err) {
    console.warn("window.top navigation failed, falling back:", err);
  }
  window.location.href = url;
}

// Navigates the Creator page hosting this widget to `url` (same window).
// Goes through the SDK first; if that isn't available, throws, or rejects,
// falls back to window.top and finally to the widget's own window.
//
// NOTE: navigateParentURL takes a config object, not a URL string — passed
// a string it rejects with "Improper Configuration..!!" without navigating.
export function navigateParentTo(url: string): void {
  try {
    const util =
      window.ZOHO && window.ZOHO.CREATOR && window.ZOHO.CREATOR.UTIL;
    if (util && typeof util.navigateParentURL === "function") {
      const nav = util.navigateParentURL({
        action: "open",
        url: url,
        window: "same",
      });
      if (nav && typeof nav.catch === "function") {
        nav.catch(function (err: any) {
          console.warn("navigateParentURL rejected, falling back:", err);
          navigateTopOrSelf(url);
        });
      }
      return;
    }
  } catch (err) {
    console.warn("navigateParentURL failed, falling back:", err);
  }
  navigateTopOrSelf(url);
}

// The header's Back button returns to the Production Targets list, which is
// where this widget's page is opened from.
export function goBackToProductionTargets(): void {
  navigateParentTo(
    creatorServiceOrigin() +
      "/" +
      CONFIG.ACCOUNT_OWNER +
      "/" +
      CONFIG.APP_NAME +
      "#Report:" +
      CONFIG.PRODUCTION_TARGET_REPORT,
  );
}

// ───────────── Production Target ─────────────
function mapProductionTargetRow(r: any): ProductionTargetRow {
  return {
    id: r.ID,
    productionTargetId: display(r.Production_Target_ID),
    date: display(r.Date_field),
    assignedTo: display(r.Assigned_To),
    assignedToId: lookupId(r.Assigned_To),
    startDate: display(r.Start_Date),
    endDate: display(r.End_Date),
    status: display(r.Status) as ProductionTargetRow["status"],
    notes: display(r.Notes),
  };
}

// The widget's own "open_production_over_v1" click action passes the
// display Production_Target_ID (e.g. "PT-118"), but several of the app's
// other status-filtered report pages (Ready For Production, Production
// Inprogress, Completed Production Target, Planned Production Target) wire
// their "Open Production Overview" click action to input.ID instead — the
// row's raw Zoho record ID (e.g. 3150000000047136). Both land here as the
// same production_target_id widget param, so detect which one we got:
// all-digits means it's the raw record ID (matched unquoted, per Creator's
// numeric-ID criteria rule), anything else is the display ID (a text
// field, so quoted).
export function fetchProductionTarget(
  productionTargetId: string,
): Promise<ProductionTargetRow | null> {
  const trimmedId = productionTargetId.trim();
  const isRecordId = /^\d+$/.test(trimmedId);
  const criteria = isRecordId
    ? `ID == ${trimmedId}`
    : `Production_Target_ID == "${trimmedId}"`;
  return getRecords(CONFIG.PRODUCTION_TARGET_REPORT, criteria).then(
    function (rows) {
      if (rows.length) return mapProductionTargetRow(rows[0]);
      if (!isRecordId) return null;

      // The "Waiting for Stock" report page is built on
      // Material_Requirement_Planning (filtered to Production_Target.Status
      // == "Waiting for Stock"), not on Production_Targets — its click
      // action passes that MRP row's own ID, which will never match a
      // Production_Targets row. Retry treating the ID as an MRP record and
      // follow its Production_Target lookup to the real target.
      return getRecords(CONFIG.MRP_REPORT, `ID == ${trimmedId}`).then(
        function (mrpRows) {
          if (!mrpRows.length) return null;
          const targetRecordId = lookupId(mrpRows[0].Production_Target);
          if (!targetRecordId) return null;
          return getRecords(
            CONFIG.PRODUCTION_TARGET_REPORT,
            `ID == ${targetRecordId}`,
          ).then(function (targetRows) {
            return targetRows.length
              ? mapProductionTargetRow(targetRows[0])
              : null;
          });
        },
      );
    },
  );
}

// ───────────── Material Requirement & Planning ─────────────
// NOTE: Material_Requirement_Planning.Production_Target is a lookup field.
// Creator's criteria engine matches lookups by the linked record's NUMERIC ID,
// NOT by display text — `Production_Target == "PT-118"` always returns 0 rows.
// Pass productionTargetRecordId (the numeric record ID from Production_Target)
// and match without quotes, same as fetchFinishedGoodsForTarget.
export function fetchMrpRecord(
  productionTargetRecordId: string,
): Promise<MrpRow | null> {
  const criteria = `Production_Target == ${productionTargetRecordId}`;
  return getRecords(CONFIG.MRP_REPORT, criteria).then(function (rows) {
    if (!rows.length) return null;
    const r = rows[0];
    return {
      id: r.ID,
      mrpId: display(r.MRP_ID),
      productionTargetId: display(r.Production_Target),
      // MRP_Date per the app's .ds export — Material_Requirement_Planning
      // has no Date_field. Status here is just "False"/"True" (unrelated to
      // stock — see MrpRow.status) — the procurement-required signal lives
      // on Production_Targets.Status instead.
      date: display(r.MRP_Date),
      createdBy: display(r.Created_By45657),
      notes: display(r.Notes),
      status: display(r.Status) as any,
    };
  });
}

// ───────────── Procurement (Non_Stock_Items → Purchase Order → Purchase Receive) ─────────────
// NOTE: the previous version of this file matched Purchase_Order/
// Purchase_Receive against a `Production_Target_ID` field that doesn't
// exist on either form (confirmed against the .ds export) — every read
// here silently returned zero rows, which is why the Procurement tab only
// ever showed plain status text. Purchase_Order only relates to a
// Production Target indirectly, via its MRP_ID lookup, so everything below
// is keyed off the MRP's own record ID instead.

// Shortfall raw materials still needing a PO (or already covered by one) —
// backs the "Needed Items" selection list in the Procurement tab.
export function fetchNonStockItemsForMrp(
  mrpRecordId: string,
): Promise<NonStockItemRow[]> {
  if (!mrpRecordId) return Promise.resolve([]);
  const criteria = `MRP_ID == ${mrpRecordId}`;
  return getRecords(CONFIG.NON_STOCK_ITEMS_REPORT, criteria).then(
    function (rows) {
      return rows.map(function (r: any) {
        return {
          id: display(r.ID),
          productId: lookupId(r.Product),
          productName: display(r.Product),
          uomId: lookupId(r.UOM),
          uomName: display(r.UOM),
          stockOnHand: parseFloat(display(r.Stock_On_Hand)) || 0,
          stockRequired: parseFloat(display(r.Stock_Required)) || 0,
          allocateQuantity: parseFloat(display(r.Allocate_Quantity)) || 0,
          neededQuantity: parseFloat(display(r.Needed_Quantity)) || 0,
          status: (display(r.Status) ||
            "Needs Purchase") as NonStockItemRow["status"],
        };
      });
    },
  );
}

let suppliersPromise: Promise<SupplierOption[]> | null = null;
let paymentTermsPromise: Promise<PaymentTermOption[]> | null = null;
let taxTypesPromise: Promise<TaxOption[]> | null = null;
let employeesPromise: Promise<EmployeeOption[]> | null = null;

export function fetchSuppliers(): Promise<SupplierOption[]> {
  if (!suppliersPromise) {
    suppliersPromise = getRecords(CONFIG.SUPPLIER_REPORT)
      .then(function (rows) {
        return rows.map(function (r: any) {
          return {
            id: display(r.ID),
            name:
              formatEmployeeName(r.Supplier_Name) ||
              display(r.Supplier_Code) ||
              "Unnamed",
          };
        });
      })
      .catch(function (error) {
        suppliersPromise = null;
        throw error;
      });
  }
  return suppliersPromise;
}

export function fetchPaymentTerms(): Promise<PaymentTermOption[]> {
  if (!paymentTermsPromise) {
    paymentTermsPromise = getRecords(CONFIG.PAYMENT_TERM_REPORT)
      .then(function (rows) {
        return rows.map(function (r: any) {
          return {
            id: display(r.ID),
            name: display(r.Payment_Terms),
          };
        });
      })
      .catch(function (error) {
        paymentTermsPromise = null;
        throw error;
      });
  }
  return paymentTermsPromise;
}

export function fetchTaxTypes(): Promise<TaxOption[]> {
  if (!taxTypesPromise) {
    taxTypesPromise = getRecords(CONFIG.TAX_MASTER_REPORT, `Status == "Active"`)
      .then(function (rows) {
        return rows.map(function (r: any) {
          return {
            id: display(r.ID),
            name: display(r.Tax_Name),
            rate: parseFloat(display(r.Tax_Rate)) || 0,
          };
        });
      })
      .catch(function (error) {
        taxTypesPromise = null;
        throw error;
      });
  }
  return taxTypesPromise;
}

// ───────────── Create Purchase Order: draft → commit ─────────────

function generatePoNumber(sequenceRow: any): string {
  const prefix = display(sequenceRow.Purchase_Name);
  const currentNo = parseInt(display(sequenceRow.Purchase_No), 10) || 0;
  return prefix + String(currentNo).padStart(3, "0");
}

function bumpPoSequence(
  sequenceRowId: string,
  currentPurchaseNo: number,
): Promise<any> {
  return updateRecord(CONFIG.SEQUENCE_MASTER_REPORT, sequenceRowId, {
    Purchase_No: currentPurchaseNo + 1,
  });
}

// Computes the draft; writes nothing to Zoho. selectedItems are the
// Non_Stock_Items rows the user checked in the Procurement tab — Order
// Quantity defaults to Needed Quantity (editable), Unit Price starts at 0
// (must have a value before submit, mirroring the native form's own
// "must have Unit_Price" rule).
export function prepareCreatePoDraft(
  mrpRecordId: string,
  selectedItems: NonStockItemRow[],
): Promise<CreatePoDraft> {
  if (!selectedItems.length) {
    return Promise.reject(
      new Error("Select at least one item to create a Purchase Order."),
    );
  }
  return fetchSequenceMasterRow().then(function (sequenceRow) {
    return {
      poNumber: generatePoNumber(sequenceRow),
      poDate: new Date().toISOString().slice(0, 10),
      mrpRecordId: mrpRecordId,
      supplierId: "",
      paymentTermsId: "",
      expectedDeliveryDate: "",
      lines: selectedItems.map(function (item) {
        return {
          nonStockItemId: item.id,
          productId: item.productId,
          productName: item.productName,
          uomId: item.uomId,
          uomName: item.uomName,
          neededQuantity: item.neededQuantity,
          orderQuantity: item.neededQuantity,
          unitPrice: 0,
          taxTypeId: "",
          taxPercentage: 0,
        };
      }),
      sequenceRowId: sequenceRow.ID,
      sequencePurchaseNo: parseInt(display(sequenceRow.Purchase_No), 10) || 0,
    };
  });
}

// Writes a confirmed draft: the Purchase_Order header, its PO_Line_Items
// rows, bumps the sequence, and flips each covered Non_Stock_Items row to
// "PO Created" — mirroring the native "Generate Purchase Order ID" /
// "Po update in Inventory" workflows (minus the Zoho Inventory sync call,
// which is out of scope — same boundary as every other zoho.inventory.*
// call in this app).
export function commitCreatePo(
  draft: CreatePoDraft,
): Promise<{ poRecordId: string; poNumber: string }> {
  // Mirrors the native line-item workflows (Calculate Unit Price / Get Tax
  // Amount): Line_Total is pre-tax (Order Qty × Unit Price), Tax_Amount is
  // Line_Total × Tax_Percentage / 100, and the header's Sub_Total/Tax_Amount/
  // Grand_Total are just the sums of those across every line.
  const computedLines = draft.lines.map(function (line) {
    const lineTotal = roundMoney(line.orderQuantity * line.unitPrice);
    const taxAmount = roundMoney((lineTotal * line.taxPercentage) / 100);
    return { line: line, lineTotal: lineTotal, taxAmount: taxAmount };
  });
  const subTotal = roundMoney(
    computedLines.reduce(function (sum, l) {
      return sum + l.lineTotal;
    }, 0),
  );
  const taxTotal = roundMoney(
    computedLines.reduce(function (sum, l) {
      return sum + l.taxAmount;
    }, 0),
  );
  const grandTotal = roundMoney(subTotal + taxTotal);

  return addRecord(CONFIG.PURCHASE_ORDER_FORM, {
    PO_Number: draft.poNumber,
    PO_Date: formatDateStringForZoho(draft.poDate),
    MRP_ID: draft.mrpRecordId,
    Supplier_Name: draft.supplierId,
    Payment_Terms: draft.paymentTermsId,
    Expected_Delivery_Date: formatDateStringForZoho(draft.expectedDeliveryDate),
    Status: "Not Received",
  }).then(function (poRecord) {
    const poRecordId: string = display(poRecord.ID);
    if (!poRecordId) {
      // Guards against ever silently writing PO_Line_Items rows with a
      // blank PO_Number lookup — better to fail the whole commit loudly
      // here than leave orphaned lines nothing in the UI can find later.
      return Promise.reject(
        new Error(
          "Purchase Order was created but its record ID couldn't be resolved — no line items were written.",
        ),
      );
    }

    return runSequentially(computedLines, function (entry) {
      const line = entry.line;
      const payload: Record<string, any> = {
        PO_Number: poRecordId,
        Product: line.productId,
        UOM: line.uomId,
        Needed_Quantity: line.neededQuantity,
        Order_Qty: line.orderQuantity,
        Unit_Price: roundMoney(line.unitPrice),
        Line_Total: entry.lineTotal,
        Tax_Percentage: roundQty(line.taxPercentage),
        Tax_Amount: entry.taxAmount,
      };
      if (line.taxTypeId) payload.Tax_Type = line.taxTypeId;
      return addRecord(CONFIG.PO_LINE_ITEMS_FORM, payload);
    })
      .then(function () {
        return runSequentially(draft.lines, function (line) {
          return updateRecord(
            CONFIG.NON_STOCK_ITEMS_REPORT,
            line.nonStockItemId,
            {
              Status: "PO Created",
            },
          );
        });
      })
      .then(function () {
        return updateRecord(CONFIG.PURCHASE_ORDER_REPORT, poRecordId, {
          Sub_Total: subTotal,
          Tax_Amount: taxTotal,
          Grand_Total: grandTotal,
        });
      })
      .then(function () {
        return bumpPoSequence(draft.sequenceRowId, draft.sequencePurchaseNo);
      })
      .then(function () {
        const result = { poRecordId: poRecordId, poNumber: draft.poNumber };
        return syncPurchaseOrderToBooks(poRecordId, draft.supplierId)
          .catch(function (err: any) {
            console.warn(
              "Books PO sync failed (Purchase Order still created in Creator):",
              err,
            );
          })
          .then(function () {
            return result;
          });
      });
  });
}

// ───────────── Read Purchase Orders (+ line items) for an MRP ─────────────

// Derives the PO's real status from its own lines instead of trusting
// Purchase_Order.Status verbatim — that field is only as good as whatever
// Deluge function last touched it, and has been seen stuck on "Partially
// Received" for a fully-received PO (a stale/incorrectly-scoped rollup on
// the Deluge side). Every line's orderQuantity/receivedQuantity is already
// being fetched here anyway, so this is a free, always-correct fallback.
function derivePoStatus(lines: PoLineRow[]): string {
  if (!lines.length) return "Not Received";
  const EPSILON = 0.0001;
  const anyReceived = lines.some(function (l) {
    return l.receivedQuantity > EPSILON;
  });
  const allFullyReceived = lines.every(function (l) {
    return l.receivedQuantity >= l.orderQuantity - EPSILON;
  });
  if (allFullyReceived) return "Received";
  if (anyReceived) return "Partially Received";
  return "Not Received";
}

export function fetchPurchaseOrdersForMrp(
  mrpRecordId: string,
): Promise<PurchaseOrderDetail[]> {
  if (!mrpRecordId) return Promise.resolve([]);
  const criteria = `MRP_ID == ${mrpRecordId}`;
  return getRecords(CONFIG.PURCHASE_ORDER_REPORT, criteria).then(
    function (rows) {
      return runSequentially(rows, function (r: any) {
        const poId = display(r.ID);
        return getRecords(
          CONFIG.PO_LINE_ITEMS_REPORT,
          `PO_Number == ${poId}`,
        ).then(function (lineRows) {
          const lines: PoLineRow[] = lineRows.map(function (line: any) {
            return {
              id: display(line.ID),
              productId: lookupId(line.Product),
              productName: display(line.Product),
              uomName: display(line.UOM),
              orderQuantity: parseFloat(display(line.Order_Qty)) || 0,
              receivedQuantity: parseFloat(display(line.Received_Qty)) || 0,
              unitPrice: parseFloat(display(line.Unit_Price)) || 0,
              taxPercentage: parseFloat(display(line.Tax_Percentage)) || 0,
              taxAmount: parseFloat(display(line.Tax_Amount)) || 0,
              lineTotal: parseFloat(display(line.Line_Total)) || 0,
            };
          });
          return {
            id: poId,
            poNumber: display(r.PO_Number),
            poDate: display(r.PO_Date),
            mrpRecordId: mrpRecordId,
            supplierId: lookupId(r.Supplier_Name),
            supplierName:
              formatEmployeeName(r.Supplier_Name) || display(r.Supplier_Name),
            status: derivePoStatus(lines),
            subTotal: parseFloat(display(r.Sub_Total)) || 0,
            taxAmount: parseFloat(display(r.Tax_Amount)) || 0,
            grandTotal: parseFloat(display(r.Grand_Total)) || 0,
            lines: lines,
          };
        });
      }).then(function (details) {
        return details.sort(function (a, b) {
          return a.poDate < b.poDate ? 1 : -1;
        });
      });
    },
  );
}

// ───────────── Receive Purchase Order: draft → commit ─────────────

function generateReceiveNo(sequenceRow: any): string {
  const prefix = display(sequenceRow.Receive_Name);
  const currentNo = parseInt(display(sequenceRow.Receive_No), 10) || 0;
  return prefix + String(currentNo).padStart(3, "0");
}

function bumpReceiveSequence(
  sequenceRowId: string,
  currentReceiveNo: number,
): Promise<any> {
  return updateRecord(CONFIG.SEQUENCE_MASTER_REPORT, sequenceRowId, {
    Receive_No: currentReceiveNo + 1,
  });
}

// Only lines with Pending Qty > 0 are included — Receivable Qty defaults
// to the full pending amount (editable down for a partial receipt).
export function prepareReceivePoDraft(
  po: PurchaseOrderDetail,
): Promise<ReceivePoDraft> {
  const pendingLines = po.lines.filter(function (line) {
    return line.orderQuantity - line.receivedQuantity > 0;
  });
  if (!pendingLines.length) {
    return Promise.reject(
      new Error("Every line on this Purchase Order has already been received."),
    );
  }

  return Promise.all([
    fetchSequenceMasterRow(),
    fetchDefaultWarehouseId(),
  ]).then(function (results) {
    const sequenceRow = results[0];
    const warehouseId = results[1];

    return {
      receiveNo: generateReceiveNo(sequenceRow),
      receiveDate: new Date().toISOString().slice(0, 10),
      purchaseOrderRecordId: po.id,
      supplierId: po.supplierId,
      warehouseId: warehouseId,
      lines: pendingLines.map(function (line) {
        const pending = roundQty(line.orderQuantity - line.receivedQuantity);
        return {
          poLineId: line.id,
          productId: line.productId,
          productName: line.productName,
          uomId: "", // resolved just before commit, see commitReceivePo
          uomName: line.uomName,
          orderedQuantity: line.orderQuantity,
          receivedQuantitySoFar: line.receivedQuantity,
          pendingQuantity: pending,
          receivableQuantity: pending,
          batchNo: "", // required on Receive_Items — filled in by the user in the dialog
          expiryDate: "",
        };
      }),
      sequenceRowId: sequenceRow.ID,
      sequenceReceiveNo: parseInt(display(sequenceRow.Receive_No), 10) || 0,
    };
  });
}

// Writes a confirmed draft: the Purchase_Receive header, its Receive_Items
// rows, bumps the sequence, then calls the "ProcessPurchaseReceive" Custom
// API — mirroring the native "Update Received Qty to PO" / "Refresh MRP
// After PR" workflows (bumping PO_Line_Items.Received_Qty, warehouse
// Stock_On_Hand, re-allocating the MRP's Raw_Materials, and rolling the PO/
// MRP/Production Target statuses up) — all of that is genuinely
// interdependent multi-record math, so it runs server-side in one call
// rather than being replicated client-side (same reasoning as
// allocate_Stock_On_Production_Start and UpdateWarehouse).
export function commitReceivePo(draft: ReceivePoDraft): Promise<any> {
  // Only the lines the user actually selected/left quantity on go to the
  // server — a line left at 0 wasn't received this round, so it shouldn't
  // get a Receive_Items row (or the phantom Batch_Details entry
  // ProcessPurchaseReceive would otherwise create for it).
  const selectedLines = draft.lines.filter(
    (line) => line.receivableQuantity > 0,
  );
  return runSequentially(selectedLines, function (line) {
    return resolveUomMasterId(line.uomName).then(function (uomMasterId) {
      return { ...line, uomId: uomMasterId };
    });
  }).then(function (linesWithUom) {
    return addRecord(CONFIG.PURCHASE_RECEIVE_FORM, {
      Receive_No: draft.receiveNo,
      Purchase_Order_No: draft.purchaseOrderRecordId,
      Receive_Date: formatDateStringForZoho(draft.receiveDate),
      Supplier: draft.supplierId,
      Warehouse: draft.warehouseId,
    }).then(function (receiveRecord) {
      const receiveRecordId: string = display(receiveRecord.ID);

      return runSequentially(linesWithUom, function (line) {
        return addRecord(CONFIG.RECEIVE_ITEMS_FORM, {
          Receive_No: receiveRecordId,
          Product_Name: line.productId,
          UOM: line.uomId,
          Ordered_Qty: line.orderedQuantity,
          Received_Qty: line.receivedQuantitySoFar,
          Receivable_Qty: line.receivableQuantity,
          Pending_Qty: roundQty(line.pendingQuantity - line.receivableQuantity),
          // Both mandatory on Receive_Items now — ProcessPurchaseReceive
          // (UpdatePR) reads them straight off each line to create/update
          // the matching Batch_Details row for whatever just arrived.
          Batch_No: line.batchNo,
          Expiry_Date: formatDateStringForZoho(line.expiryDate),
        });
      })
        .then(function () {
          return bumpReceiveSequence(
            draft.sequenceRowId,
            draft.sequenceReceiveNo,
          );
        })
        .then(function () {
          return processPurchaseReceive(receiveRecordId);
        })
        .then(function (result) {
          return syncPurchaseReceiveToBooks(receiveRecordId, draft.supplierId)
            .catch(function (err: any) {
              console.warn(
                "Books PR sync failed (Purchase Receive still recorded in Creator):",
                err,
              );
            })
            .then(function () {
              return result;
            });
        });
    });
  });
}

// Published as "UpdatePR" in Microservices (function: ProcessPurchaseReceive).
const PROCESS_PURCHASE_RECEIVE_API = {
  api_name: "UpdatePR",
  workspace_name: "info_divinafoodco",
  public_key: "dq5NsNjaEPBpSQ4z9fgH9mp7x",
};

function processPurchaseReceive(receiveRecordId: string): Promise<any> {
  if (!PROCESS_PURCHASE_RECEIVE_API.public_key) {
    return Promise.reject(
      new Error(
        "ProcessPurchaseReceive Custom API isn't wired up yet — the receipt was recorded, but stock/MRP status won't update until this is configured.",
      ),
    );
  }
  return window.ZOHO.CREATOR.DATA.invokeCustomApi({
    api_name: PROCESS_PURCHASE_RECEIVE_API.api_name,
    workspace_name: PROCESS_PURCHASE_RECEIVE_API.workspace_name,
    http_method: "POST",
    content_type: "application/json",
    payload: {
      receive_id: receiveRecordId,
    },
    public_key: PROCESS_PURCHASE_RECEIVE_API.public_key,
  }).then(function (resp: any) {
    const result = resp && resp.result;
    if (
      !resp ||
      resp.code !== 3000 ||
      (result && result.status && result.status !== "success")
    ) {
      return Promise.reject(
        new Error(
          (result && result.message) ||
            "Failed to process the purchase receive.",
        ),
      );
    }
    return resp;
  });
}

// ───────────── Books sync (Purchase Order / Purchase Receive) ─────────────
// Best-effort: Creator is the source of truth for the PO/PR workflow itself,
// so a Books sync failure never rejects commitCreatePo/commitReceivePo —
// callers just get the record they asked for either way. Errors are logged
// so they're visible without blocking the user on an integration that's
// still being hardened (tax fields, purchasereceives payload format, etc.).

// Published as "syncPO" in Microservices (function: PO.SyncCreatorToBooks).
const SYNC_PO_TO_BOOKS_API = {
  api_name: "syncPO",
  workspace_name: "info_divinafoodco",
  public_key: "rWapybq1J9GCpXkDeXHQ8NBwz",
};

export function syncPurchaseOrderToBooks(
  purchaseOrderRecordId: string,
  supplierRecordId: string,
): Promise<any> {
  return window.ZOHO.CREATOR.DATA.invokeCustomApi({
    api_name: SYNC_PO_TO_BOOKS_API.api_name,
    workspace_name: SYNC_PO_TO_BOOKS_API.workspace_name,
    http_method: "POST",
    content_type: "application/json",
    payload: {
      purchase_id: purchaseOrderRecordId,
      supplier_id: supplierRecordId,
    },
    public_key: SYNC_PO_TO_BOOKS_API.public_key,
  }).then(function (resp: any) {
    const result = resp && resp.result;
    // Checked against result.code (set on every branch of PO.SyncCreatorToBooks,
    // success or failure) rather than result.status, which is only ever set
    // on the success branch and would silently miss every error response.
    if (!resp || resp.code !== 3000 || !result || result.code !== 3000) {
      return Promise.reject(
        new Error(
          (result && result.message) ||
            "Failed to sync Purchase Order to Books.",
        ),
      );
    }
    return result;
  });
}

// Published as "syncPR" in Microservices (function: PR.SyncCreatorToBooks).
const SYNC_PR_TO_BOOKS_API = {
  api_name: "syncPR",
  workspace_name: "info_divinafoodco",
  public_key: "U7eygp4uRCBx6jWMB0Aa2KN9C",
};

export function syncPurchaseReceiveToBooks(
  receiveRecordId: string,
  supplierRecordId: string,
): Promise<any> {
  return window.ZOHO.CREATOR.DATA.invokeCustomApi({
    api_name: SYNC_PR_TO_BOOKS_API.api_name,
    workspace_name: SYNC_PR_TO_BOOKS_API.workspace_name,
    http_method: "POST",
    content_type: "application/json",
    payload: {
      receive_id: receiveRecordId,
      supplier_id: supplierRecordId,
    },
    public_key: SYNC_PR_TO_BOOKS_API.public_key,
  }).then(function (resp: any) {
    const result = resp && resp.result;
    if (!resp || resp.code !== 3000 || !result || result.code !== 3000) {
      return Promise.reject(
        new Error(
          (result && result.message) ||
            "Failed to sync Purchase Receive to Books.",
        ),
      );
    }
    return result;
  });
}

// Published as "Check_stock_in_MRP" in Microservices (function: MRP.CheckStock).
// Re-checks every still-short Raw_Materials row on an MRP against the
// warehouse's current Available_Stocks, reserves whatever now covers it,
// and releases the linked Production Target once nothing is left short —
// the "Check Stock" button's whole job.
const CHECK_STOCK_API = {
  api_name: "Check_stock_in_MRP",
  workspace_name: "info_divinafoodco",
  public_key: "GXgPnYWkkv6Bs7QO2APnChuUn",
};

export function checkStockForMrp(mrpRecordId: string): Promise<any> {
  return window.ZOHO.CREATOR.DATA.invokeCustomApi({
    api_name: CHECK_STOCK_API.api_name,
    workspace_name: CHECK_STOCK_API.workspace_name,
    http_method: "POST",
    content_type: "application/json",
    payload: {
      mrp_id: mrpRecordId,
    },
    public_key: CHECK_STOCK_API.public_key,
  }).then(function (resp: any) {
    const result = resp && resp.result;
    if (
      !resp ||
      resp.code !== 3000 ||
      (result && result.status && result.status !== "success")
    ) {
      return Promise.reject(
        new Error(
          (result && result.message) || "Failed to check stock for this MRP.",
        ),
      );
    }
    return resp;
  });
}

// ───────────── Production In-progress ─────────────
// Confirmed against the app's .ds export — this report is just
// Production_Targets filtered to Status == "In Progress"; there is no
// separate Assigned_By/Production_Status field, only the target's own
// Assigned_To/Status (the fields the "Complete Production" custom action
// column sits alongside natively).
export function fetchProductionInProgress(
  productionTargetId: string,
): Promise<ProductionInProgressRow[]> {
  const criteria = `Production_Target_ID == "${productionTargetId}"`;
  return getRecords(CONFIG.PRODUCTION_INPROGRESS_REPORT, criteria).then(
    function (rows) {
      return rows.map(function (r: any) {
        return {
          id: r.ID,
          productionTargetId: display(r.Production_Target_ID),
          date: display(r.Date_field),
          assignedBy: display(r.Assigned_To),
          productionStatus: display(r.Status),
        };
      });
    },
  );
}

// ───────────── Consumption Entry ─────────────
// Consumption_Entry.Production_Target is a lookup — match by the
// Production Target's numeric record ID, same rule as every other lookup
// criteria in this file. Each entry's two grids (Finished_Good,
// Raw_Material_Consumptions) are separate subform-backing reports
// (Finished_Goods_Cunsumptions, Consumption_Items), so they're fetched by
// criteria on their own back-reference lookup, same pattern used for the
// MRP's Finished_Goods/Raw_Materials.
export function fetchConsumptionEntries(
  productionTargetRecordId: string,
): Promise<ConsumptionEntryRow[]> {
  if (!productionTargetRecordId) return Promise.resolve([]);
  const criteria = `Production_Target == ${productionTargetRecordId}`;
  return getRecords(CONFIG.CONSUMPTION_ENTRY_REPORT, criteria)
    .then(function (rows) {
      // Sequential (not Promise.all) — see runSequentially's comment:
      // enough entries fired at once trips Creator's cap on simultaneous
      // in-flight API calls (code 2955).
      return runSequentially(rows, function (r: any) {
        const entryId = display(r.ID);
        return Promise.all([
          getRecords(
            CONFIG.FINISHED_GOODS_CONSUMPTIONS_REPORT,
            `Consumption_Entry == ${entryId}`,
          ),
          getRecords(
            CONFIG.CONSUMPTION_ITEMS_REPORT,
            `Consumption_ID == ${entryId}`,
          ),
        ]).then(function (sub) {
          const finishedGoods = sub[0].map(function (fg: any) {
            return {
              id: display(fg.ID),
              itemId: lookupId(fg.Finished_Good),
              itemName: display(fg.Finished_Good),
              uom: "",
              targetQuantity: parseFloat(display(fg.Target_Quantity)) || 0,
              producedQuantity: parseFloat(display(fg.Produced_Quantity)) || 0,
              scrapQuantity: parseFloat(display(fg.Scrap_Quantity)) || 0,
              batchNo: display(fg.Batch_No),
              expiryDate: display(fg.Expiry_Date),
            };
          });
          const rawMaterials = sub[1].map(function (rm: any) {
            return {
              id: display(rm.ID),
              productId: lookupId(rm.Raw_Material),
              productName: display(rm.Raw_Material),
              uom: display(rm.UOM),
              allocatedQuantity:
                parseFloat(display(rm.Allocated_Quantity)) || 0,
              consumedQuantity: parseFloat(display(rm.Consumed_Quantity)) || 0,
              scrapQuantity: parseFloat(display(rm.Scrap_Quantity)) || 0,
            };
          });
          return {
            id: entryId,
            consumptionId: display(r.Consumption_ID),
            productionTargetId: display(r.Production_Target),
            date: display(r.Date_field),
            remarks: display(r.Remarks),
            finishedGoods: finishedGoods,
            rawMaterials: rawMaterials,
          };
        });
      });
    })
    .then(function (entries) {
      return entries.sort(function (a, b) {
        return a.date < b.date ? 1 : -1;
      });
    });
}

// ───────────── Create MRP ─────────────

// Finished-good lines already attached to the Production Target (added when
// the target itself was created). These are what get exploded through their
// BOM below, and later get their MRP_ID set once the new MRP exists.
//
// NOTE: Finished_Goods.Production_Target_ID is a lookup field, and Creator's
// criteria engine matches lookups as NUMBER (the linked record's ID) rather
// than by display text — `Production_Target_ID == "PT-114"` throws
// "Invalid criteria specified" (code 3330) here, unlike the plain-text
// Production_Target_ID field on Production_Targets itself. So this one
// takes the Production Target's record ID, not its display ID string.
export function fetchFinishedGoodsForTarget(
  productionTargetRecordId: string,
): Promise<FinishedGoodTargetRow[]> {
  const criteria = `Production_Target_ID == ${productionTargetRecordId}`;
  return getRecords(CONFIG.FINISHED_GOODS_REPORT, criteria).then(
    function (rows) {
      return rows.map(function (r: any) {
        return {
          id: r.ID,
          productionTargetRecordId: lookupId(r.Production_Target_ID),
          itemId: lookupId(r.Item),
          itemName: display(r.Item),
          uomId: lookupId(r.UOM),
          uomName: display(r.UOM),
          targetQuantity: parseFloat(display(r.Target_Quantity)) || 0,
        };
      });
    },
  );
}

// A finished good's BOM_Master row has a single BOM_Items grid — look up the
// BOM by its Product (the finished good), then read that BOM's items.
function fetchBomItemsForProduct(itemId: string): Promise<BomItemRow[]> {
  if (!itemId) return Promise.resolve([]);

  const bomCriteria = `Product == ${itemId}`;
  return getRecords(CONFIG.BOM_MASTER_REPORT, bomCriteria).then(
    function (bomRows) {
      if (!bomRows.length) return [];
      const bomId = bomRows[0].ID;

      const itemsCriteria = `BOM_ID == ${bomId}`;
      return getRecords(CONFIG.BOM_ITEMS_REPORT, itemsCriteria).then(
        function (itemRows) {
          return itemRows.map(function (r: any) {
            return {
              bomId: display(bomId),
              productId: lookupId(r.Product),
              productName: display(r.Product),
              quantityRequired: parseFloat(display(r.Quantity_Required)) || 0,
              uomId: lookupId(r.UOM),
              uomName: display(r.UOM),
            };
          });
        },
      );
    },
  );
}

// Available_Stocks is the source of truth for current stock — sum it across
// every Main_Warehouse_Stock_Details row for a raw material (normally just
// one, since there's a single Main Warehouse). Batched across every raw
// material aggregated MRP needs at once: this used to be one getRecords
// round trip per product, run through runSequentially (see its comment —
// Creator's cap on simultaneous in-flight calls rules out just Promise.all-ing
// them). A production target with 6 raw materials meant 6 sequential
// ~300-500ms round trips back to back before the Create MRP draft could even
// render. A single OR'd criteria gets every product's rows in one request
// instead, with no change to what's fetched or how it's aggregated.
function fetchStockOnHandBatch(
  productIds: string[],
): Promise<Record<string, number>> {
  const uniqueIds = Array.from(new Set(productIds.filter(Boolean)));
  if (!uniqueIds.length) return Promise.resolve({});

  const criteria = uniqueIds
    .map(function (id) {
      return `Product_Master == ${id}`;
    })
    .join(" || ");

  return getRecords(CONFIG.MAIN_WAREHOUSE_STOCK_REPORT, criteria).then(
    function (rows) {
      const totals: Record<string, number> = {};
      rows.forEach(function (r: any) {
        const productId = lookupId(r.Product_Master);
        if (!productId) return;
        const available = parseFloat(display(r.Available_Stocks)) || 0;
        totals[productId] = (totals[productId] || 0) + available;
      });
      return totals;
    },
  );
}

// Explodes every finished good through its BOM × Target_Quantity, aggregates
// duplicate raw materials across multiple finished-good lines, then compares
// the aggregated requirement to current stock to work out what's short.
function computeRawMaterialNeeds(
  finishedGoods: FinishedGoodTargetRow[],
): Promise<RawMaterialNeedRow[]> {
  // Sequential (not Promise.all) — see runSequentially's comment: enough
  // finished goods/raw materials fired at once trips Creator's cap on
  // simultaneous in-flight API calls (code 2955).
  return runSequentially(finishedGoods, function (fg) {
    return fetchBomItemsForProduct(fg.itemId).then(function (bomItems) {
      return bomItems.map(function (item) {
        return {
          productId: item.productId,
          productName: item.productName,
          uom: item.uomName,
          requiredQuantity: roundQty(item.quantityRequired * fg.targetQuantity),
        };
      });
    });
  }).then(function (perFinishedGood) {
    const aggregated = new Map<
      string,
      {
        productId: string;
        productName: string;
        uom: string;
        stockRequired: number;
      }
    >();

    perFinishedGood.forEach(function (lines) {
      lines.forEach(function (line) {
        const existing = aggregated.get(line.productId);
        if (existing) {
          existing.stockRequired = roundQty(
            existing.stockRequired + line.requiredQuantity,
          );
        } else {
          aggregated.set(line.productId, {
            productId: line.productId,
            productName: line.productName,
            uom: line.uom,
            stockRequired: line.requiredQuantity,
          });
        }
      });
    });

    const aggregatedList = Array.from(aggregated.values());

    return fetchStockOnHandBatch(
      aggregatedList.map(function (rm) {
        return rm.productId;
      }),
    ).then(function (stockByProduct) {
      return aggregatedList.map(function (rm) {
        const stockOnHand = roundQty(stockByProduct[rm.productId] || 0);
        const allocateQuantity = roundQty(
          Math.min(stockOnHand, rm.stockRequired),
        );
        const neededQuantity = roundQty(
          Math.max(0, rm.stockRequired - stockOnHand),
        );
        return {
          productId: rm.productId,
          productName: rm.productName,
          uom: rm.uom,
          stockOnHand: stockOnHand,
          stockRequired: rm.stockRequired,
          allocateQuantity: allocateQuantity,
          neededQuantity: neededQuantity,
          status: (neededQuantity > 0
            ? "Needs Purchase"
            : "Stock Available") as RawMaterialNeedRow["status"],
        };
      });
    });
  });
}

// Sequence_Master holds a single row of running counters. MRP_ID is that
// row's MRP_Name prefix + MRP_No zero-padded to 3 digits (e.g. "MRP-045"),
// mirroring the app's native Deluge "Generate MRP ID" workflow.
function fetchSequenceMasterRow(): Promise<any> {
  return getRecords(CONFIG.SEQUENCE_MASTER_REPORT).then(function (rows) {
    if (!rows.length)
      return Promise.reject(
        new Error("Sequence_Master has no row configured."),
      );
    return rows[0];
  });
}

function generateMrpId(sequenceRow: any): string {
  const prefix = display(sequenceRow.MRP_Name);
  const currentNo = parseInt(display(sequenceRow.MRP_No), 10) || 0;
  return prefix + String(currentNo).padStart(3, "0");
}

// Only call this once the full MRP create has succeeded — bumping the
// counter first would burn a sequence number on a failed/partial create.
function bumpMrpSequence(
  sequenceRowId: string,
  currentMrpNo: number,
): Promise<any> {
  return updateRecord(CONFIG.SEQUENCE_MASTER_REPORT, sequenceRowId, {
    MRP_No: currentMrpNo + 1,
  });
}

// Non_Stock_Items.UOM is a lookup to UOM_Master, but our raw-material rows
// only carry the UOM as plain text (same as the native "Generate MRP ID"
// workflow's own get_line.UOM) — resolve it the same way that workflow
// does: match UOM_Master's own UOM text field.
function resolveUomMasterId(uomText: string): Promise<string> {
  if (!uomText) return Promise.resolve("");
  return getRecords(CONFIG.UOM_MASTER_REPORT, `UOM == "${uomText}"`).then(
    function (rows) {
      return rows.length ? display(rows[0].ID) : "";
    },
  );
}

// The app only ever books MRPs against "Main Warehouse" — no picker needed,
// just resolve that one Warehouse_Master row's own record ID, which is what
// gets written into MRP.Warehouse (a lookup to Warehouse_Master).
function fetchDefaultWarehouseId(): Promise<string> {
  const criteria = `Warehouse_Name == "Main Warehouse"`;
  return getRecords(CONFIG.WAREHOUSE_REPORT, criteria).then(function (rows) {
    if (!rows.length) {
      return Promise.reject(
        new Error('Could not find a "Main Warehouse" row in Warehouse_Master.'),
      );
    }
    return display(rows[0].ID);
  });
}

// Same "Main Warehouse" row as fetchDefaultWarehouseId, but its plain-text
// code (Warehouse_ID, e.g. "WH-001") instead of its record ID — needed
// alongside the record ID when creating a fresh Main_Warehouse_Stock_Details
// row (see reserveMainWarehouseStockForMrp), which stores both a lookup
// (Warehouse) and a denormalized code (Warehouse_Code), matching the native
// MRP "on add success" workflow's own insert shape.
function fetchDefaultWarehouseCode(): Promise<string> {
  const criteria = `Warehouse_Name == "Main Warehouse"`;
  return getRecords(CONFIG.WAREHOUSE_REPORT, criteria).then(function (rows) {
    if (!rows.length) return "";
    return display(rows[0].Warehouse_ID);
  });
}

// Generic Warehouse_Master lookup by its plain-text code (Warehouse_ID field
// — e.g. "WH-001" for Main Warehouse, "WH-003" for Scrap Warehouse), matching
// the pattern used by the Deluge "on add" workflows already replicated in
// this file (Warehouse_Master[Warehouse_ID == "WH-001"] etc.) rather than by
// Warehouse_Name. Returns both the record ID (for a lookup field write) and
// the code itself (for a denormalized Warehouse_Code write), or null if no
// such warehouse row exists.
function fetchWarehouseByCode(
  code: string,
): Promise<{ id: string; code: string } | null> {
  const criteria = `Warehouse_ID == "${code}"`;
  return getRecords(CONFIG.WAREHOUSE_REPORT, criteria).then(function (rows) {
    if (!rows.length) return null;
    return { id: display(rows[0].ID), code: display(rows[0].Warehouse_ID) };
  });
}

function formatDateForZoho(date: Date): string {
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const day = String(date.getDate()).padStart(2, "0");
  return `${day}-${months[date.getMonth()]}-${date.getFullYear()}`;
}

// Converts date strings ("YYYY-MM-DD" or standard formats) to Zoho's "DD-Mon-YYYY" format.
function formatDateStringForZoho(dateStr: string): string {
  if (!dateStr) return "";
  const parts = dateStr.split("-");
  if (parts.length === 3 && parts[1].length === 3 && isNaN(Number(parts[1]))) {
    return dateStr;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return formatDateForZoho(new Date(dateStr + "T00:00:00"));
  }
  const d = new Date(dateStr);
  if (!isNaN(d.getTime())) {
    return formatDateForZoho(d);
  }
  return dateStr;
}

// ───────────── Create MRP: two-phase draft → commit ─────────────
// Phase 1 (prepareMrpDraft) computes everything a new MRP would contain —
// finished goods, BOM-exploded raw material needs, the generated MRP_ID —
// without writing anything, so the UI can show a full preview (mirroring
// the native "Generate MRP ID" form) before the user confirms. Phase 2
// (commitMrpDraft) only runs once the user clicks Create in that preview.

// Computes the draft; writes nothing to Zoho.
export function prepareMrpDraft(
  productionTargetRecordId: string,
  productionTargetId: string,
): Promise<MrpDraft> {
  // Guard against duplicate MRPs — a second attempt after a page reload (or
  // a second tab) while an earlier one was still mid-flight would otherwise
  // race the Sequence_Master read and produce two headers with the same
  // generated MRP_ID. This doesn't fully close the race (both checks can
  // still run before either commit finishes) but it catches the common case
  // where the first MRP has already landed by the time this one starts.
  // Uses productionTargetRecordId (numeric) since Production_Target is a lookup field.
  return fetchMrpRecord(productionTargetRecordId).then(function (existingMrp) {
    if (existingMrp) {
      return Promise.reject(
        new Error(
          `An MRP (${existingMrp.mrpId}) already exists for this Production Target.`,
        ),
      );
    }

    return Promise.all([
      fetchFinishedGoodsForTarget(productionTargetRecordId),
      fetchSequenceMasterRow(),
      fetchDefaultWarehouseId(),
      fetchDefaultWarehouseCode(),
    ]).then(function (results) {
      const finishedGoods = results[0];
      const sequenceRow = results[1];
      const warehouseId = results[2];
      const warehouseCode = results[3];

      if (!finishedGoods.length) {
        return Promise.reject(
          new Error(
            "This Production Target has no finished-good lines yet — add at least one before creating an MRP.",
          ),
        );
      }

      return computeRawMaterialNeeds(finishedGoods).then(
        function (rawMaterials) {
          const hasShortfall = rawMaterials.some(function (rm) {
            return rm.status === "Needs Purchase";
          });

          return {
            mrpId: generateMrpId(sequenceRow),
            mrpDate: formatDateForZoho(new Date()),
            productionTargetRecordId: productionTargetRecordId,
            productionTargetId: productionTargetId,
            warehouseId: warehouseId,
            warehouseCode: warehouseCode,
            finishedGoods: finishedGoods,
            rawMaterials: rawMaterials,
            hasShortfall: hasShortfall,
            sequenceRowId: sequenceRow.ID,
            sequenceMrpNo: parseInt(display(sequenceRow.MRP_No), 10) || 0,
          };
        },
      );
    });
  });
}

// Mirrors the Reserved_Stock loop in Material_Requirement_Planning's own
// "on add, on success" workflow: for every raw material line, bump the
// matching Main_Warehouse_Stock_Details row's Reserved_Stock by
// Allocate_Quantity and recompute Available_Stocks = Stock_On_Hand -
// Reserved_Stock, or create a fresh row (Reserved_Stock only, matching the
// native insert's own field list — it doesn't set Stock_On_Hand/
// Available_Stocks either) when this product has never had a warehouse
// stock row before. Like every other "on add" workflow in this file, this
// never fires for an MRP created via the JS SDK's addRecords, so without
// this replica an MRP created through the widget never reserves anything
// against Main Warehouse stock even though its Raw_Materials rows look
// correct.
//
// Reverted the batched OR'd-criteria existence check (12 -> 7 calls) back to
// one getRecords per raw material — the batched read wasn't reliably
// finding/matching rows via this SDK's criteria handling, so reservations
// were silently not landing. Back to a plain per-item check-then-write,
// which is confirmed to actually reserve stock correctly, at the cost of
// more round trips (12 calls for 6 raw materials instead of 7).
//
// Sequential (not Promise.all) — see runSequentially's comment: Creator's
// cap on simultaneous in-flight API calls (code 2955).
function reserveMainWarehouseStockForMrp(draft: MrpDraft): Promise<void> {
  return runSequentially(draft.rawMaterials, function (rm) {
    const criteria = `Product_Master == ${rm.productId}`;
    return getRecords(CONFIG.MAIN_WAREHOUSE_STOCK_REPORT, criteria).then(
      function (rows) {
        if (rows.length > 0) {
          const row = rows[0];
          const reservedStock = roundQty(
            (parseFloat(display(row.Reserved_Stock)) || 0) +
              rm.allocateQuantity,
          );
          const stockOnHand = parseFloat(display(row.Stock_On_Hand)) || 0;
          return updateRecord(
            CONFIG.MAIN_WAREHOUSE_STOCK_REPORT,
            display(row.ID),
            {
              Reserved_Stock: reservedStock,
              Available_Stocks: roundQty(stockOnHand - reservedStock),
            },
          );
        }
        return addRecord(CONFIG.MAIN_WAREHOUSE_STOCK_FORM, {
          Warehouse_Code: draft.warehouseCode,
          Warehouse: draft.warehouseId,
          Product_Master: rm.productId,
          Reserved_Stock: rm.allocateQuantity,
        });
      },
    );
  }).then(function () {
    return undefined;
  });
}

// Writes a confirmed draft: MRP header, fresh Finished_Goods rows scoped to
// the MRP, Raw_Materials rows, the Production Target's Status update, and
// finally the Sequence_Master bump — only after everything else has
// succeeded, so a failed/partial commit doesn't burn a sequence number.
export function commitMrpDraft(
  draft: MrpDraft,
  notes: string,
): Promise<CreateMrpResult> {
  // The procurement-required signal belongs on Production_Targets.Status
  // (values Planned/Released/Waiting for Stock/In Progress/Completed,
  // confirmed against the app's .ds export), NOT on the MRP record —
  // Material_Requirement_Planning.Status is a separate, unrelated
  // True/False field that always gets its native default here.
  const productionTargetStatus: ProductionTargetStatus = draft.hasShortfall
    ? "Waiting for Stock"
    : "Released";

  return addRecord(CONFIG.MRP_FORM, {
    MRP_ID: draft.mrpId,
    Production_Target: draft.productionTargetRecordId,
    Warehouse: draft.warehouseId,
    MRP_Date: draft.mrpDate,
    Notes: notes,
    Status: "False",
  }).then(function (mrpRecord) {
    const mrpRecordId: string = display(mrpRecord.ID);

    // Mirrors the native "Generate MRP ID" workflow: it creates fresh
    // Finished_Goods rows scoped to the MRP (Item/UOM/Target_Quantity
    // copied over, MRP_ID set), rather than re-linking the rows already
    // attached to the Production Target — those stay exactly as they
    // were, under Production_Target_ID only.
    //
    // Sequential (not Promise.all) — see runSequentially's comment: enough
    // finished goods/raw materials fired at once trips Creator's cap on
    // simultaneous in-flight API calls (code 2955).
    return runSequentially(draft.finishedGoods, function (fg) {
      return addRecord(CONFIG.FINISHED_GOODS_FORM, {
        MRP_ID: mrpRecordId,
        Item: fg.itemId,
        UOM: fg.uomId,
        Target_Quantity: fg.targetQuantity,
      });
    })
      .then(function () {
        return runSequentially(draft.rawMaterials, function (rm) {
          return addRecord(CONFIG.RAW_MATERIALS_FORM, {
            MRP_ID: mrpRecordId,
            Product_Name: rm.productId,
            UOM: rm.uom,
            Stock_On_hand: rm.stockOnHand,
            Stock_Required: rm.stockRequired,
            Allocate_Quantity: rm.allocateQuantity,
            Needed_Quantity: rm.neededQuantity,
            Status: rm.status,
          });
        });
      })
      .then(function () {
        return reserveMainWarehouseStockForMrp(draft);
      })
      .then(function () {
        // Mirrors the native "Generate MRP ID" form's own "on add, on
        // success" workflow, which creates a Non_Stock_Items row for every
        // raw material line with Needed_Quantity > 0 — this is what backs
        // the "Required Materials" custom action on the MRP list
        // (opens Non_Stock_Items_Report?MRP_ID=...). That workflow doesn't
        // fire for MRPs created via the JS SDK's addRecords, same reason as
        // every other "on add" workflow replicated in this file, so without
        // this an MRP created through the widget shows "No Data Available"
        // there even though its Raw_Materials/procurement status are fine.
        const shortfallRawMaterials = draft.rawMaterials.filter(function (rm) {
          return rm.neededQuantity > 0;
        });
        return runSequentially(shortfallRawMaterials, function (rm) {
          return resolveUomMasterId(rm.uom).then(function (uomMasterId) {
            return addRecord(CONFIG.NON_STOCK_ITEMS_FORM, {
              MRP_ID: mrpRecordId,
              Product: rm.productId,
              UOM: uomMasterId,
              Stock_On_Hand: rm.stockOnHand,
              Stock_Required: rm.stockRequired,
              Allocate_Quantity: rm.allocateQuantity,
              Needed_Quantity: rm.neededQuantity,
              Status: "Needs Purchase",
            });
          });
        });
      })
      .then(function () {
        return updateRecord(
          CONFIG.PRODUCTION_TARGET_REPORT,
          draft.productionTargetRecordId,
          {
            Status: productionTargetStatus,
          },
        );
      })
      .then(function () {
        return bumpMrpSequence(draft.sequenceRowId, draft.sequenceMrpNo);
      })
      .then(function () {
        return {
          mrpRecordId: mrpRecordId,
          mrpId: draft.mrpId,
          rawMaterials: draft.rawMaterials,
        };
      });
  });
}

// ───────────── MRP Details (Finished Goods & Raw Materials for Report) ─────────────

export function fetchFinishedGoodsForMrp(
  mrpRecordId: string,
  productionTargetRecordId?: string,
): Promise<FinishedGoodTargetRow[]> {
  const criteria = `MRP_ID == ${mrpRecordId}`;
  return getRecords(CONFIG.FINISHED_GOODS_REPORT, criteria).then(
    function (rows) {
      if (rows && rows.length > 0) {
        return rows.map(function (r: any) {
          return {
            id: r.ID,
            productionTargetRecordId:
              lookupId(r.Production_Target_ID) ||
              productionTargetRecordId ||
              "",
            itemId: lookupId(r.Item),
            itemName: display(r.Item),
            uomId: lookupId(r.UOM),
            uomName: display(r.UOM),
            targetQuantity: parseFloat(display(r.Target_Quantity)) || 0,
          };
        });
      }
      // Fallback: lookup by Production Target record ID if not tagged with MRP_ID yet
      if (productionTargetRecordId) {
        return fetchFinishedGoodsForTarget(productionTargetRecordId);
      }
      return [];
    },
  );
}

export function fetchRawMaterialsForMrp(
  mrpRecordId: string,
): Promise<RawMaterialNeedRow[]> {
  const criteria = `MRP_ID == ${mrpRecordId}`;
  return getRecords(CONFIG.RAW_MATERIALS_REPORT, criteria).then(
    function (rows) {
      if (!rows || !rows.length) return [];
      return rows.map(function (r: any) {
        return {
          productId:
            lookupId(r.Product_Name) ||
            lookupId(r.Product) ||
            display(r.Product_Name),
          productName: display(r.Product_Name) || display(r.Product),
          uom: display(r.UOM),
          stockOnHand:
            parseFloat(display(r.Stock_On_hand || r.Stock_On_Hand)) || 0,
          stockRequired: parseFloat(display(r.Stock_Required)) || 0,
          allocateQuantity:
            parseFloat(display(r.Allocate_Quantity || r.Allocated_Qty)) || 0,
          neededQuantity:
            parseFloat(display(r.Needed_Quantity || r.Needed_Qty)) || 0,
          status: (display(r.Status) ||
            "Stock Available") as RawMaterialNeedRow["status"],
        };
      });
    },
  );
}

export function fetchMrpDetails(
  mrpRecord: MrpRow,
  productionTargetRecordId: string,
): Promise<MrpDetailData> {
  return Promise.all([
    fetchFinishedGoodsForMrp(mrpRecord.id, productionTargetRecordId),
    fetchRawMaterialsForMrp(mrpRecord.id),
  ]).then(function (results) {
    const finishedGoods = results[0];
    let rawMaterials = results[1];

    if (rawMaterials.length > 0) {
      const hasShortfall = rawMaterials.some(function (rm) {
        return rm.status === "Needs Purchase";
      });
      return {
        mrpRecord: mrpRecord,
        finishedGoods: finishedGoods,
        rawMaterials: rawMaterials,
        hasShortfall: hasShortfall,
      };
    }

    // Fallback: If Raw_Materials_Report has no rows returned (e.g. mock data or unindexed),
    // compute needs dynamically from finished goods BOM
    if (finishedGoods.length > 0) {
      return computeRawMaterialNeeds(finishedGoods).then(function (computed) {
        const hasShortfall = computed.some(function (rm) {
          return rm.status === "Needs Purchase";
        });
        return {
          mrpRecord: mrpRecord,
          finishedGoods: finishedGoods,
          rawMaterials: computed,
          hasShortfall: hasShortfall,
        };
      });
    }

    return {
      mrpRecord: mrpRecord,
      finishedGoods: [],
      rawMaterials: [],
      hasShortfall: false,
    };
  });
}

// ───────────── Start Production ─────────────

export function fetchEmployees(): Promise<EmployeeOption[]> {
  if (!employeesPromise) {
    employeesPromise = getRecords(CONFIG.EMPLOYEE_REPORT)
      .then(function (rows) {
        return rows.map(function (r: any) {
          return {
            id: r.ID,
            name:
              formatEmployeeName(r.Employee_Name) ||
              display(r.Employee_ID) ||
              "Unnamed",
          };
        });
      })
      .catch(function (error) {
        employeesPromise = null;
        throw error;
      });
  }
  return employeesPromise;
}

// Starts production for a Production Target by setting its status to "In Progress"
// and updating its Start_Date, End_Date, and Assigned_To from the user input.
export function startProduction(
  productionTargetRecordId: string,
  details: StartProductionDetails,
): Promise<any> {
  const payload: Record<string, any> = {
    Status: "In Progress" as ProductionTargetStatus,
    Start_Date: formatDateStringForZoho(details.startDate),
  };
  if (details.endDate) {
    payload.End_Date = formatDateStringForZoho(details.endDate);
  }
  if (details.assignedToId) {
    payload.Assigned_To = details.assignedToId;
  }

  return updateRecord(
    CONFIG.PRODUCTION_TARGET_REPORT,
    productionTargetRecordId,
    payload,
  );
}

// ⚠️ Fill these in from the Custom API's Summary page in Microservices.
// workspace_name is the ACCOUNT/workspace slug ("info_divinafoodco"),
// NOT the same as CONFIG.APP_NAME ("divina-foods") used elsewhere in this file.
const ALLOCATE_STOCK_API = {
  api_name: "allocate_Stock_On_Production_Start",
  workspace_name: "info_divinafoodco",
  public_key: "u3utxmSOfbbUK11zdtkbHptps",
};

// Calls the Custom API that runs the allocateStockOnProductionStart Deluge
// function — allocates raw-material stock for this Production Target's MRP.
// Does NOT touch Production_Target.Status; that's still startProduction()'s job.
export function allocateStockOnProductionStart(
  productionTargetRecordId: string,
): Promise<any> {
  return window.ZOHO.CREATOR.DATA.invokeCustomApi({
    api_name: ALLOCATE_STOCK_API.api_name,
    workspace_name: ALLOCATE_STOCK_API.workspace_name,
    http_method: "POST",
    content_type: "application/json",
    payload: {
      production_target_id: productionTargetRecordId,
    },
    public_key: ALLOCATE_STOCK_API.public_key,
  }).then(function (resp: any) {
    // Zoho's own convention (used throughout this file for getRecords/
    // addRecords/updateRecordById) is code 3000 = success — NOT an HTTP-style
    // "< 400 is success" scheme. This response's own success codes (3000,
    // and error codes like 3001/3330 seen elsewhere in this app) are all
    // >= 400 numerically, so a `resp.code >= 400` check flags every
    // successful call as a failure. Check the actual shape instead:
    // { code: 3000, result: { status: "success", message: "...", ... } }.
    const result = resp && resp.result;
    if (
      !resp ||
      resp.code !== 3000 ||
      (result && result.status && result.status !== "success")
    ) {
      return Promise.reject(
        new Error(
          (result && result.message) ||
            "Failed to allocate stock for production.",
        ),
      );
    }
    return resp;
  });
}

// Published as "AllocateAndCommitBatch" in Microservices
// (function: FEFO.AllocateAndCommitBatch). Supersedes allocateStockOnProductionStart
// above (left in place, just no longer called) — does the FEFO batch pick
// AND the Reserved_Stock → Committed_Stocks transition in one call, and
// hands back which specific batch(es) each raw material was drawn from so
// the widget can show it.
const ALLOCATE_AND_COMMIT_BATCH_API = {
  api_name: "AllocateAndCommitBatch",
  workspace_name: "info_divinafoodco",
  public_key: "RWgBNeUuWqXC9BrfSavqwT3fT",
};

// Resolves once the Deluge function has done the FEFO pick, the
// Reserved_Stock → Committed_Stocks transition, AND written a persistent
// FEFO_Batch_Allocation record (+ its Batch_Allocation lines) for this
// production target. The widget never parses the response's own
// "allocations" field for display — those are Deluge's raw 17-digit record
// IDs (batch_lineRec.ID / batch_lineRec.Product_Master) put into the
// response Map untouched, which exceed Number.MAX_SAFE_INTEGER and silently
// round on the JSON round-trip to the browser (classic
// large-int-as-JSON-number precision loss) — that's why the batch card used
// to show a garbled numeric ID instead of the item name. Reading the
// persisted record back through getRecords (see
// fetchBatchAllocationsForProductionTarget below) sidesteps that entirely,
// since Zoho's own REST API always returns record IDs as precision-safe
// strings — and it's what makes the breakdown survive a page reload too.
export function allocateAndCommitBatch(
  productionTargetRecordId: string,
): Promise<void> {
  return window.ZOHO.CREATOR.DATA.invokeCustomApi({
    api_name: ALLOCATE_AND_COMMIT_BATCH_API.api_name,
    workspace_name: ALLOCATE_AND_COMMIT_BATCH_API.workspace_name,
    http_method: "POST",
    content_type: "application/json",
    payload: {
      production_target_id: productionTargetRecordId,
    },
    public_key: ALLOCATE_AND_COMMIT_BATCH_API.public_key,
  }).then(function (resp: any) {
    const result = resp && resp.result;
    if (
      !resp ||
      resp.code !== 3000 ||
      (result && result.status && result.status !== "success")
    ) {
      return Promise.reject(
        new Error(
          (result && result.message) ||
            "Failed to allocate batches for this production run.",
        ),
      );
    }
  });
}

// Reads back the FEFO_Batch_Allocation record (+ its Batch_Allocation grid)
// that AllocateAndCommitBatch persists for a production target — same
// two-step header-then-lines pattern as fetchPurchaseOrders/PO_Line_Items.
// Both Batch_NO and Product are configured with a displayformat
// ([Batch_Number] / [Product_Name] respectively), so display() on them
// already returns the human-readable text, not the raw ID.
export function fetchBatchAllocationsForProductionTarget(
  productionTargetRecordId: string,
): Promise<BatchAllocationLine[]> {
  if (!productionTargetRecordId) return Promise.resolve([]);
  const criteria = `Production_Targets == ${productionTargetRecordId}`;
  return getRecords(CONFIG.FEFO_BATCH_ALLOCATION_REPORT, criteria).then(
    function (headerRows) {
      if (!headerRows || !headerRows.length) return [];
      // One header per Start Production click — if it's ever clicked more
      // than once for the same target, use the most recently created one.
      const headerId = headerRows[headerRows.length - 1].ID;
      return getRecords(
        CONFIG.BATCH_ALLOCATION_REPORT,
        `FEFO_Batch_ID == ${headerId}`,
      ).then(function (rows) {
        if (!rows || !rows.length) return [];
        return rows.map(function (r: any): BatchAllocationLine {
          return {
            batchId: lookupId(r.Batch_NO) || display(r.Batch_NO),
            batchNumber: display(r.Batch_NO) || undefined,
            productId: lookupId(r.Product) || display(r.Product),
            productName: display(r.Product) || undefined,
            expiryDate: display(r.Expiry_Date),
            stockOnHand: parseFloat(display(r.Stock_On_Hand)) || 0,
            batchQty: parseFloat(display(r.Batch_Qty)) || 0,
            remainingQty: parseFloat(display(r.Remaining_Qty)) || 0,
          };
        });
      });
    },
  );
}

// ───────────── Complete Production (Consumption Entry) ─────────────
// Mirrors the native "Complete Production" custom action on the
// Production_Inprogress list: that action just opens the Consumption_Entry
// form as a popup pre-filled with Production_Target=input.ID. The actual
// pre-fill (finished goods from the target, raw materials from the MRP's
// allocated quantities) lives in Consumption_Entry's own "Fetch Production
// Target" form-load workflow, and the "mark Completed" step lives in its
// "on add success" workflow — both are UI/record-level Deluge that only
// fires for Creator's own form, not for records created via the JS SDK, so
// prepareConsumptionDraft/commitConsumptionEntry replicate them here.
//
// The downstream Scrap/Main/Production warehouse stock bookkeeping (see
// updateWarehouseStockForConsumption below) is replicated client-side too —
// it used to go through an "UpdateWarehouse" Custom API/Deluge function, but
// that repeatedly failed to actually persist the Scrap Warehouse updates
// despite returning a clean success response, so it's now done directly
// against the Data API from here instead.

function generateConsumptionId(sequenceRow: any): string {
  const prefix = display(sequenceRow.Consumption_Name);
  const currentNo = parseInt(display(sequenceRow.Consumption_No), 10) || 0;
  return prefix + String(currentNo).padStart(3, "0");
}

function bumpConsumptionSequence(
  sequenceRowId: string,
  currentConsumptionNo: number,
): Promise<any> {
  return updateRecord(CONFIG.SEQUENCE_MASTER_REPORT, sequenceRowId, {
    Consumption_No: currentConsumptionNo + 1,
  });
}

// Computes the draft; writes nothing to Zoho. Finished-good lines default
// Produced_Quantity to the full Target_Quantity (edited down by the user if
// the run fell short); raw-material lines default Consumed_Quantity to the
// MRP's already-allocated quantity.
export function prepareConsumptionDraft(
  productionTargetRecordId: string,
  productionTargetId: string,
  mrpRecordId: string,
): Promise<ConsumptionEntryDraft> {
  return Promise.all([
    fetchFinishedGoodsForTarget(productionTargetRecordId),
    mrpRecordId
      ? fetchRawMaterialsForMrp(mrpRecordId)
      : Promise.resolve([] as RawMaterialNeedRow[]),
    fetchSequenceMasterRow(),
  ]).then(function (results) {
    const finishedGoods = results[0];
    const rawMaterials = results[1];
    const sequenceRow = results[2];

    if (!finishedGoods.length) {
      return Promise.reject(
        new Error(
          "This Production Target has no finished-good lines to log production against.",
        ),
      );
    }

    return {
      productionTargetRecordId: productionTargetRecordId,
      productionTargetId: productionTargetId,
      consumptionId: generateConsumptionId(sequenceRow),
      date: new Date().toISOString().slice(0, 10),
      remarks: "",
      finishedGoods: finishedGoods.map(function (fg) {
        return {
          itemId: fg.itemId,
          itemName: fg.itemName,
          uom: fg.uomName,
          targetQuantity: fg.targetQuantity,
          producedQuantity: fg.targetQuantity,
          scrapQuantity: 0,
          batchNo: "",
          // Defaults to the same "today" as the header Date field — this run
          // is being completed now, so that's the sensible default MFD; the
          // user can pull it back if manufacturing actually finished earlier.
          manufacturingDate: new Date().toISOString().slice(0, 10),
          expiryDate: "",
        };
      }),
      rawMaterials: rawMaterials.map(function (rm) {
        return {
          productId: rm.productId,
          productName: rm.productName,
          uom: rm.uom,
          allocatedQuantity: rm.allocateQuantity,
          consumedQuantity: rm.allocateQuantity,
          scrapQuantity: 0,
        };
      }),
      sequenceRowId: sequenceRow.ID,
      sequenceConsumptionNo:
        parseInt(display(sequenceRow.Consumption_No), 10) || 0,
    };
  });
}

// Replicates the "on add, on success" warehouse bookkeeping directly against
// the Data API instead of through the "UpdateWarehouse" Custom API — that
// Deluge function kept returning a clean {code:3000, status:"success"}
// response while silently never creating/updating the Scrap Warehouse rows
// (root cause never pinned down after checking the deployed code, the
// Warehouse_Master WH-003 lookup value, and the response body all coming
// back clean), so this does the same field-for-field logic as plain
// getRecords/addRecord/updateRecord calls from here, where it's directly
// inspectable and debuggable.
//
// Every step is independent (its own existence check, no step gated behind
// an unrelated one) and runs sequentially, not in parallel — see
// runSequentially's comment on Creator's cap on simultaneous in-flight API
// calls (code 2955). This costs more round trips than the single Custom API
// call did, but each one is a plain, ordinary Data API call with nothing
// hidden in Deluge to go wrong.
const BATCH_NUMBER_PREFIX = "BFG-";
const BATCH_NUMBER_DIGITS = 6;

function findUnusedBatchNumber(
  candidateNo: number,
  attempt: number,
): Promise<string> {
  const candidate =
    BATCH_NUMBER_PREFIX +
    String(candidateNo).padStart(BATCH_NUMBER_DIGITS, "0");
  if (attempt > 5) return Promise.resolve(candidate);
  return getRecords(
    CONFIG.BATCH_DETAILS_REPORT,
    `Batch_Number == "${candidate}"`,
  ).then(function (existing) {
    if (!existing.length) return candidate;
    return findUnusedBatchNumber(candidateNo + 1, attempt + 1);
  });
}

// Generates the next "BFG-000001"-style batch number for the Complete
// Production dialog's Batch No field. Derives the next number from the
// highest existing BFG- batch already in Batch_Details (no dedicated
// counter field needed on Sequence_Master), then double-checks the
// candidate itself so a hand-typed batch number out of sequence (e.g.
// someone typed "BFG-000050" manually) can never collide with it.
export function generateNextBatchNumber(): Promise<string> {
  const criteria = `Batch_Number.startsWith("${BATCH_NUMBER_PREFIX}")`;
  return getRecords(CONFIG.BATCH_DETAILS_REPORT, criteria, 1000).then(
    function (rows) {
      let maxNo = 0;
      rows.forEach(function (r: any) {
        const suffix = display(r.Batch_Number).slice(
          BATCH_NUMBER_PREFIX.length,
        );
        const num = parseInt(suffix, 10);
        if (!isNaN(num) && num > maxNo) maxNo = num;
      });
      return findUnusedBatchNumber(maxNo + 1, 0);
    },
  );
}

function updateWarehouseStockForConsumption(
  draft: ConsumptionEntryDraft,
): Promise<void> {
  function updateOrCreateMainWarehouseForFinishedGood(
    fg: (typeof draft.finishedGoods)[number],
  ): Promise<any> {
    const criteria = `Product_Master == ${fg.itemId}`;
    return getRecords(CONFIG.MAIN_WAREHOUSE_STOCK_REPORT, criteria).then(
      function (rows) {
        if (rows.length > 0) {
          const row = rows[0];
          const stockOnHand = roundQty(
            (parseFloat(display(row.Stock_On_Hand)) || 0) + fg.producedQuantity,
          );
          return updateRecord(
            CONFIG.MAIN_WAREHOUSE_STOCK_REPORT,
            display(row.ID),
            {
              Stock_On_Hand: stockOnHand,
              Available_Stocks: stockOnHand,
            },
          );
        }
        return fetchWarehouseByCode("WH-001").then(function (mainWh) {
          if (!mainWh) return null;
          return addRecord(CONFIG.MAIN_WAREHOUSE_STOCK_FORM, {
            Warehouse_Code: mainWh.code,
            Warehouse: mainWh.id,
            Product_Master: fg.itemId,
            Stock_On_Hand: fg.producedQuantity,
            Available_Stocks: fg.producedQuantity,
          });
        });
      },
    );
  }

  function updateOrCreateScrapWarehouse(
    productId: string,
    scrapQuantity: number,
  ): Promise<any> {
    if (!(scrapQuantity > 0)) return Promise.resolve(null);
    const criteria = `Product_Master == ${productId}`;
    return getRecords(CONFIG.SCRAP_WAREHOUSE_STOCK_REPORT, criteria).then(
      function (rows) {
        if (rows.length > 0) {
          const row = rows[0];
          return updateRecord(
            CONFIG.SCRAP_WAREHOUSE_STOCK_REPORT,
            display(row.ID),
            {
              Scrap_Quantity: roundQty(
                (parseFloat(display(row.Scrap_Quantity)) || 0) + scrapQuantity,
              ),
            },
          );
        }
        return fetchWarehouseByCode("WH-003").then(function (scrapWh) {
          if (!scrapWh) return null;
          return addRecord(CONFIG.SCRAP_WAREHOUSE_STOCK_FORM, {
            Warehouse_Code: scrapWh.code,
            Warehouse: scrapWh.id,
            Product_Master: productId,
            Scrap_Quantity: scrapQuantity,
          });
        });
      },
    );
  }

  function releaseMainWarehouseForRawMaterial(
    rm: (typeof draft.rawMaterials)[number],
  ): Promise<any> {
    const criteria = `Product_Master == ${rm.productId}`;
    return getRecords(CONFIG.MAIN_WAREHOUSE_STOCK_REPORT, criteria).then(
      function (rows) {
        if (!rows.length) return null;
        const row = rows[0];
        return updateRecord(
          CONFIG.MAIN_WAREHOUSE_STOCK_REPORT,
          display(row.ID),
          {
            Committed_Stocks: roundQty(
              (parseFloat(display(row.Committed_Stocks)) || 0) -
                rm.allocatedQuantity,
            ),
            Stock_On_Hand: roundQty(
              (parseFloat(display(row.Stock_On_Hand)) || 0) -
                rm.allocatedQuantity,
            ),
          },
        );
      },
    );
  }

  function releaseProductionWarehouseForRawMaterial(
    rm: (typeof draft.rawMaterials)[number],
  ): Promise<any> {
    const criteria = `Product_Master == ${rm.productId}`;
    return getRecords(CONFIG.PRODUCTION_STOCK_REPORT, criteria).then(
      function (rows) {
        if (!rows.length) return null;
        const row = rows[0];
        return updateRecord(CONFIG.PRODUCTION_STOCK_REPORT, display(row.ID), {
          Committed_Stocks: roundQty(
            (parseFloat(display(row.Committed_Stocks)) || 0) -
              rm.allocatedQuantity,
          ),
        });
      },
    );
  }

  // Per-batch tracking, per the native workflow: a finished good's own
  // Batch_Details row is looked up by Batch_Number (not scoped to a
  // product — batch numbers are treated as unique on their own), updated if
  // found, or created fresh if this is the first time that batch number has
  // ever been logged.
  function updateOrCreateBatchDetailsForFinishedGood(
    fg: (typeof draft.finishedGoods)[number],
  ): Promise<any> {
    if (!fg.batchNo) return Promise.resolve(null);
    const criteria = `Batch_Number == "${fg.batchNo}"`;
    return getRecords(CONFIG.BATCH_DETAILS_REPORT, criteria).then(
      function (rows) {
        if (rows.length > 0) {
          const row = rows[0];
          return updateRecord(CONFIG.BATCH_DETAILS_REPORT, display(row.ID), {
            Stock_On_Hand: roundQty(
              (parseFloat(display(row.Stock_On_Hand)) || 0) +
                fg.producedQuantity,
            ),
          });
        }
        return addRecord(CONFIG.BATCH_DETAILS_FORM, {
          Product_Master: fg.itemId,
          Batch_Number: fg.batchNo,
          Manufacturing_Date: formatDateStringForZoho(fg.manufacturingDate),
          Expiry_Date: formatDateStringForZoho(fg.expiryDate),
          Stock_On_Hand: fg.producedQuantity,
          Available_Stocks: fg.producedQuantity,
        });
      },
    );
  }

  // Per-batch release for raw materials, per the native workflow: finds
  // whichever specific batch(es) FEFO_Batch_Allocation picked for this raw
  // material back at Start Production, releases that batch's own
  // Committed_Stocks/Stock_On_Hand by the allocated amount, and deletes the
  // batch once it's fully used up (Stock_On_Hand - Committed_Stocks <= 0) --
  // same as the native workflow's own "if Available_Stocks == 0, delete"
  // check, just computed here since a plain getRecords/updateRecord round
  // trip doesn't have Deluge's in-session recalculated field to read back.
  // Runs alongside (not instead of) the warehouse-total release above, per
  // an explicit choice to keep both in sync rather than only one of them.
  function releaseBatchDetailsForRawMaterial(
    batchAllocationLines: BatchAllocationLine[],
    rm: (typeof draft.rawMaterials)[number],
  ): Promise<any> {
    const matchingLines = batchAllocationLines.filter(function (line) {
      return line.productId === rm.productId && !!line.batchId;
    });
    return runSequentially(matchingLines, function (line) {
      return getRecords(
        CONFIG.BATCH_DETAILS_REPORT,
        `ID == ${line.batchId}`,
      ).then(function (rows) {
        if (!rows.length) return null;
        const row = rows[0];
        const committedStocks = roundQty(
          (parseFloat(display(row.Committed_Stocks)) || 0) - line.batchQty,
        );
        const stockOnHand = roundQty(
          (parseFloat(display(row.Stock_On_Hand)) || 0) - line.batchQty,
        );
        const availableStocks = roundQty(stockOnHand - committedStocks);
        if (availableStocks <= 0) {
          return deleteRecord(CONFIG.BATCH_DETAILS_REPORT, display(row.ID));
        }
        return updateRecord(CONFIG.BATCH_DETAILS_REPORT, display(row.ID), {
          Committed_Stocks: committedStocks,
          Stock_On_Hand: stockOnHand,
        });
      });
    });
  }

  return runSequentially(
    draft.finishedGoods.filter(function (fg) {
      return !!fg.itemId;
    }),
    function (fg) {
      return updateOrCreateMainWarehouseForFinishedGood(fg)
        .then(function () {
          return updateOrCreateBatchDetailsForFinishedGood(fg);
        })
        .then(function () {
          return updateOrCreateScrapWarehouse(fg.itemId, fg.scrapQuantity);
        });
    },
  )
    .then(function () {
      // Fetched once up front (not per raw material) — the same FEFO pick
      // covers every raw material on this production target, so this is a
      // single read reused across the whole loop below.
      return fetchBatchAllocationsForProductionTarget(
        draft.productionTargetRecordId,
      );
    })
    .then(function (batchAllocationLines) {
      return runSequentially(
        draft.rawMaterials.filter(function (rm) {
          return !!rm.productId;
        }),
        function (rm) {
          return releaseMainWarehouseForRawMaterial(rm)
            .then(function () {
              return releaseProductionWarehouseForRawMaterial(rm);
            })
            .then(function () {
              return releaseBatchDetailsForRawMaterial(
                batchAllocationLines,
                rm,
              );
            })
            .then(function () {
              return updateOrCreateScrapWarehouse(
                rm.productId,
                rm.scrapQuantity,
              );
            });
        },
      );
    })
    .then(function () {
      return undefined;
    });
}

// Writes a confirmed draft: the Consumption_Entry header, its two subform
// rows (Finished_Goods_Cunsumptions, Consumption_Items), flips the
// Production Target to "Completed" (mirroring the native form's on-success
// workflow), bumps the Sequence_Master counter, and updates warehouse stock
// (see updateWarehouseStockForConsumption) — only after everything else has
// succeeded, so a failed/partial commit doesn't burn a sequence number.
export function commitConsumptionEntry(
  draft: ConsumptionEntryDraft,
): Promise<ConsumptionEntryRow> {
  return addRecord(CONFIG.CONSUMPTION_ENTRY_FORM, {
    Consumption_ID: draft.consumptionId,
    Production_Target: draft.productionTargetRecordId,
    Date_field: formatDateStringForZoho(draft.date),
    Remarks: draft.remarks,
  }).then(function (entryRecord) {
    const entryId: string = display(entryRecord.ID);

    // Every step below is chained sequentially (not fired in parallel via
    // Promise.all) — see runSequentially's comment: a multi-line entry
    // (several finished goods + several raw materials, each needing its own
    // insert/lookup/update calls) fired all at once trips Zoho Creator's cap
    // on simultaneous in-flight API calls (code 2955).
    return runSequentially(draft.finishedGoods, function (fg) {
      // Batch_No, MFD_Date and Expiry_Date are all mandatory on this form now
      // (MFD_Date and Expiry_Date are "must have" fields) — the dialog's
      // canSubmit already blocks the commit until every line has all three,
      // so these are sent unconditionally rather than only-if-present.
      const payload: Record<string, any> = {
        Consumption_Entry: entryId,
        Finished_Good: fg.itemId,
        Target_Quantity: fg.targetQuantity,
        Produced_Quantity: fg.producedQuantity,
        Scrap_Quantity: fg.scrapQuantity,
        Batch_No: fg.batchNo,
        MFD_Date: formatDateStringForZoho(fg.manufacturingDate),
        Expiry_Date: formatDateStringForZoho(fg.expiryDate),
      };
      return addRecord(CONFIG.FINISHED_GOODS_CONSUMPTIONS_FORM, payload);
    })
      .then(function () {
        return runSequentially(draft.rawMaterials, function (rm) {
          return addRecord(CONFIG.CONSUMPTION_ITEMS_FORM, {
            Consumption_ID: entryId,
            Raw_Material: rm.productId,
            UOM: rm.uom,
            Allocated_Quantity: rm.allocatedQuantity,
            Consumed_Quantity: rm.consumedQuantity,
            Scrap_Quantity: rm.scrapQuantity,
          });
        });
      })
      .then(function () {
        return updateRecord(
          CONFIG.PRODUCTION_TARGET_REPORT,
          draft.productionTargetRecordId,
          {
            Status: "Completed" as ProductionTargetStatus,
          },
        );
      })
      .then(function () {
        return updateWarehouseStockForConsumption(draft);
      })
      .then(function () {
        return bumpConsumptionSequence(
          draft.sequenceRowId,
          draft.sequenceConsumptionNo,
        );
      })
      .then(function () {
        return {
          id: entryId,
          consumptionId: draft.consumptionId,
          productionTargetId: draft.productionTargetId,
          date: formatDateStringForZoho(draft.date),
          remarks: draft.remarks,
          finishedGoods: draft.finishedGoods.map(function (fg) {
            return { id: "", ...fg };
          }),
          rawMaterials: draft.rawMaterials.map(function (rm) {
            return { id: "", ...rm };
          }),
        };
      });
  });
}

// Fetch everything the Production Overview page needs
export function fetchProductionOverview(productionTargetId: string): Promise<{
  record: ProductionTargetRow | null;
  mrpRecord: MrpRow | null;
  mrpDetails: MrpDetailData | null;
  nonStockItems: NonStockItemRow[];
  procurementRecords: PurchaseOrderDetail[];
  productionInProgress: ProductionInProgressRow[];
  consumptionEntries: ConsumptionEntryRow[];
  finishedGoodsForTarget: FinishedGoodTargetRow[];
}> {
  return fetchProductionTarget(productionTargetId).then(function (record) {
    if (!record) {
      return Promise.resolve({
        record: null as ProductionTargetRow | null,
        mrpRecord: null as MrpRow | null,
        mrpDetails: null as MrpDetailData | null,
        nonStockItems: [] as NonStockItemRow[],
        procurementRecords: [] as PurchaseOrderDetail[],
        productionInProgress: [] as ProductionInProgressRow[],
        consumptionEntries: [] as ConsumptionEntryRow[],
        finishedGoodsForTarget: [] as FinishedGoodTargetRow[],
      });
    }

    // These three only need record/productionTargetId, not mrpRecord — start
    // them right away instead of nesting them inside fetchMrpRecord's .then
    // below, which used to force them to wait for the MRP lookup to finish
    // before even starting even though none of them depends on its result.
    // Finished_Goods rows for the target exist from the moment the
    // Production Target itself is created (see fetchFinishedGoodsForTarget's
    // own comment on the two-Finished_Goods-rows-per-run architecture), so
    // the Overview tab can show them before an MRP even exists.
    const productionInProgressPromise =
      fetchProductionInProgress(productionTargetId);
    const consumptionEntriesPromise = fetchConsumptionEntries(record.id);
    const finishedGoodsForTargetPromise = fetchFinishedGoodsForTarget(
      record.id,
    );

    return fetchMrpRecord(record.id).then(function (mrpRecord) {
      const mrpDetailsPromise = mrpRecord
        ? fetchMrpDetails(mrpRecord, record.id)
        : Promise.resolve(null as MrpDetailData | null);
      const nonStockItemsPromise = mrpRecord
        ? fetchNonStockItemsForMrp(mrpRecord.id)
        : Promise.resolve([] as NonStockItemRow[]);
      const purchaseOrdersPromise = mrpRecord
        ? fetchPurchaseOrdersForMrp(mrpRecord.id)
        : Promise.resolve([] as PurchaseOrderDetail[]);

      return Promise.all([
        purchaseOrdersPromise,
        productionInProgressPromise,
        consumptionEntriesPromise,
        mrpDetailsPromise,
        nonStockItemsPromise,
        finishedGoodsForTargetPromise,
      ]).then(function (rest) {
        return {
          record,
          mrpRecord,
          mrpDetails: rest[3] as MrpDetailData | null,
          nonStockItems: rest[4] as NonStockItemRow[],
          procurementRecords: rest[0] as PurchaseOrderDetail[],
          productionInProgress: rest[1],
          consumptionEntries: rest[2],
          finishedGoodsForTarget: rest[5] as FinishedGoodTargetRow[],
        };
      });
    });
  });
}
